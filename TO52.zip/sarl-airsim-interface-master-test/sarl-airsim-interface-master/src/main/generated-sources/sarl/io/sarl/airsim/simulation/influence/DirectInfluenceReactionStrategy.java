package io.sarl.airsim.simulation.influence;

import io.sarl.lang.core.Address;
import io.sarl.lang.core.annotation.SarlElementType;
import io.sarl.lang.core.annotation.SarlSpecification;
import io.sarl.lang.core.annotation.SyntheticMember;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure0;

/**
 * Influences should be applied as soon as they are received.
 * Perceptions are propagated as soon as they are received.
 * @author Alexandre Lombard
 */
@SarlSpecification("0.13")
@SarlElementType(10)
@SuppressWarnings("all")
public class DirectInfluenceReactionStrategy implements InfluenceReactionStrategy {
  public void influenceReceived(final Address source, final Procedure0 propagate) {
    propagate.apply();
  }

  public void perceptionReceived(final Address destination, final Procedure0 propagate) {
    propagate.apply();
  }

  @SyntheticMember
  public DirectInfluenceReactionStrategy() {
    super();
  }
}
