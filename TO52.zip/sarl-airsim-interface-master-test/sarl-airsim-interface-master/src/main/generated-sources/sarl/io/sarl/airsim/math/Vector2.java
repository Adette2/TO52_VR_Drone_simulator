package io.sarl.airsim.math;

import io.sarl.lang.core.annotation.SarlElementType;
import io.sarl.lang.core.annotation.SarlSpecification;
import io.sarl.lang.core.annotation.SyntheticMember;
import java.util.Objects;
import org.eclipse.xtext.xbase.lib.Pure;

/**
 * Represents a 2D vector (immutable)
 * @author Alexandre Lombard
 */
@SarlSpecification("0.13")
@SarlElementType(10)
@SuppressWarnings("all")
public class Vector2 implements Vector<Vector2> {
  /**
   * X coordinate
   */
  public final Float x;

  /**
   * Y coordinate
   */
  public final Float y;

  /**
   * Builds a null-vector
   */
  public Vector2() {
    this(Float.valueOf(0.0f), Float.valueOf(0.0f));
  }

  /**
   * Builds a vector with the given parameters
   * @param x the X coordinate
   * @param y the Y coordinate
   */
  public Vector2(final Float x, final Float y) {
    this.x = x;
    this.y = y;
  }

  /**
   * Getter for X
   * @return X
   */
  @Pure
  public Float getX() {
    return this.x;
  }

  /**
   * Getter for Y
   * @return Y
   */
  @Pure
  public Float getY() {
    return this.y;
  }

  /**
   * Operator plus, computes the sum of two vectors (this and v)
   * @param v the vector to add
   * @return the sum of this and v
   */
  @Pure
  public Vector2 operator_plus(final Vector2 v) {
    return new Vector2(Float.valueOf((((this.x) == null ? 0 : (this.x).floatValue()) + ((v.x) == null ? 0 : (v.x).floatValue()))), Float.valueOf((((this.y) == null ? 0 : (this.y).floatValue()) + ((v.y) == null ? 0 : (v.y).floatValue()))));
  }

  /**
   * Operator minus, computes the difference of two vectors (this and v)
   * @param v the vector to subtract
   * @return the difference of this and v
   */
  @Pure
  public Vector2 operator_minus(final Vector2 v) {
    return new Vector2(Float.valueOf((((this.x) == null ? 0 : (this.x).floatValue()) - ((v.x) == null ? 0 : (v.x).floatValue()))), Float.valueOf((((this.y) == null ? 0 : (this.y).floatValue()) - ((v.y) == null ? 0 : (v.y).floatValue()))));
  }

  /**
   * Operator multiply, computes the product of this vector by a scalar
   * @param l the scalar
   * @return the product of this by the given scalar
   */
  public Vector2 operator_multiply(final Float l) {
    return new Vector2(Float.valueOf((((this.x) == null ? 0 : (this.x).floatValue()) * ((l) == null ? 0 : (l).floatValue()))), Float.valueOf((((this.y) == null ? 0 : (this.y).floatValue()) * ((l) == null ? 0 : (l).floatValue()))));
  }

  /**
   * Operator multiply, computes the product of this vector by a scalar
   * @param l the scalar
   * @return the product of this by the given scalar
   */
  @Pure
  public Vector2 operator_multiply(final Float l, final Vector2 v) {
    return new Vector2(Float.valueOf((((v.x) == null ? 0 : (v.x).floatValue()) * ((l) == null ? 0 : (l).floatValue()))), Float.valueOf((((v.y) == null ? 0 : (v.y).floatValue()) * ((l) == null ? 0 : (l).floatValue()))));
  }

  /**
   * Unary minus operator
   */
  public Vector2 operator_minus() {
    return new Vector2(Float.valueOf((-((this.x) == null ? 0 : (this.x).floatValue()))), Float.valueOf((-((this.y) == null ? 0 : (this.y).floatValue()))));
  }

  @Pure
  public Float toAngle() {
    return Float.valueOf(Double.valueOf(Math.atan2(((this.y) == null ? 0 : (this.y).floatValue()), ((this.x) == null ? 0 : (this.x).floatValue()))).floatValue());
  }

  /**
   * Gets the squared norm of this vector
   * @return the squared norm of this vector
   */
  public Float squaredNorm() {
    return Float.valueOf(((((this.x) == null ? 0 : (this.x).floatValue()) * ((this.x) == null ? 0 : (this.x).floatValue())) + (((this.y) == null ? 0 : (this.y).floatValue()) * ((this.y) == null ? 0 : (this.y).floatValue()))));
  }

  /**
   * Gets the norm of this vector
   * @return the norm of this vector
   */
  public Float norm() {
    return Float.valueOf(Double.valueOf(Math.sqrt(((this.squaredNorm()) == null ? 0 : (this.squaredNorm()).floatValue()))).floatValue());
  }

  /**
   * Computes the dot product of this vector and v
   * @param v the other vector
   * @return the dot product
   */
  @Override
  @Pure
  public Float dot(final Vector2 v) {
    return Float.valueOf(((((this.x) == null ? 0 : (this.x).floatValue()) * ((v.x) == null ? 0 : (v.x).floatValue())) + (((this.y) == null ? 0 : (this.y).floatValue()) * ((v.y) == null ? 0 : (v.y).floatValue()))));
  }

  /**
   * Gets the String representation of this vector
   * @return a String showing the coordinates of this vector
   */
  @Override
  @Pure
  public String toString() {
    return (((("[" + this.x) + ", ") + this.y) + "]");
  }

  @Override
  @Pure
  @SyntheticMember
  public boolean equals(final Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    Vector2 other = (Vector2) obj;
    if (other.x == null) {
      if (this.x != null)
        return false;
    } else if (this.x == null)
      return false;if (other.x != null && Float.floatToIntBits(other.x.floatValue()) != Float.floatToIntBits(this.x.floatValue()))
      return false;
    if (other.y == null) {
      if (this.y != null)
        return false;
    } else if (this.y == null)
      return false;if (other.y != null && Float.floatToIntBits(other.y.floatValue()) != Float.floatToIntBits(this.y.floatValue()))
      return false;
    return super.equals(obj);
  }

  @Override
  @Pure
  @SyntheticMember
  public int hashCode() {
    int result = super.hashCode();
    final int prime = 31;
    result = prime * result + Objects.hashCode(this.x);
    result = prime * result + Objects.hashCode(this.y);
    return result;
  }
}
