package io.sarl.airsim.math;

import io.sarl.lang.core.annotation.SarlElementType;
import io.sarl.lang.core.annotation.SarlSpecification;
import org.eclipse.xtext.xbase.lib.Pure;

/**
 * Generic interface for vectors
 * @author Alexandre Lombard
 */
@SarlSpecification("0.13")
@SarlElementType(11)
@SuppressWarnings("all")
public interface Vector<T extends Vector<T>> {
  /**
   * Gets the length of this vector (equivalent to norm())
   * @return the norm of this vector
   */
  @Pure
  default Float length() {
    return this.norm();
  }

  /**
   * Gets the squared norm of this vector
   * @return the squared norm of this vector
   */
  Float squaredNorm();

  /**
   * Gets the norm of this vector
   * @return the norm of this vector
   */
  default Float norm() {
    return Float.valueOf(Double.valueOf(Math.sqrt(((this.squaredNorm()) == null ? 0 : (this.squaredNorm()).floatValue()))).floatValue());
  }

  /**
   * Gets the normalized form of this vector
   * @return the normalized vector
   */
  default T normalized() {
    Float _norm = this.norm();
    return this.operator_multiply(Float.valueOf((1.0f / ((_norm) == null ? 0 : (_norm).floatValue()))));
  }

  /**
   * Operator plus, computes the sum of two vectors (this and v)
   * @param v the vector to add
   * @return the sum of this and v
   */
  T operator_plus(final T v);

  /**
   * Plus function, equivalent to this + v
   * @param v the vector to add
   * @return the sum of this and v
   */
  @Pure
  default T plus(final T v) {
    return this.operator_plus(v);
  }

  /**
   * Minus function, equivalent to this - v
   * @param v the vector to subtract
   * @return the difference of this and v
   */
  @Pure
  default T minus(final T v) {
    return this.operator_minus(v);
  }

  /**
   * Operator minus, computes the difference of two vectors (this and v)
   * @param v the vector to subtract
   * @return the difference of this and v
   */
  T operator_minus(final T v);

  /**
   * Times function, equivalent to this * l, computes the product of this vector by a scalar
   * @param l the scalar
   * @return the product of this by the given scalar
   */
  @Pure
  default T times(final Float l) {
    return this.operator_multiply(l);
  }

  /**
   * Operator multiply, computes the product of this vector by a scalar
   * @param l the scalar
   * @return the product of this by the given scalar
   */
  T operator_multiply(final Float l);

  /**
   * Operator multiply, computes the product of this vector by a scalar
   * @param l the scalar
   * @return the product of this by the given scalar
   */
  T operator_multiply(final Float l, final T v);

  /**
   * Unary minus operator
   */
  T operator_minus();

  /**
   * Computes the dot product of this vector and v
   * @param v the other vector
   * @return the dot product
   */
  Float dot(final T v);
}
