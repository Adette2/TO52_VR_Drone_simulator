package io.sarl.airsim.simulation.allocation;

import io.sarl.lang.core.Address;
import io.sarl.lang.core.annotation.DefaultValue;
import io.sarl.lang.core.annotation.DefaultValueSource;
import io.sarl.lang.core.annotation.SarlElementType;
import io.sarl.lang.core.annotation.SarlSpecification;
import io.sarl.lang.core.annotation.SyntheticMember;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure2;
import org.eclipse.xtext.xbase.lib.Pure;

/**
 * Represents an allocation strategy proposing a fixed pool of bodies.
 * The attribution of the body follows the policy "first come, first served".
 * The body will be attributed in the order of the iteration on the elements of the pool.
 * @author Alexandre Lombard
 */
@SarlSpecification("0.13")
@SarlElementType(10)
@SuppressWarnings("all")
public class FcfsFixedSizePoolAllocationStrategy implements AllocationStrategy {
  private final Queue<String> pool = CollectionLiterals.<String>newLinkedList();

  private final ConcurrentHashMap<Address, String> affectations = new ConcurrentHashMap<Address, String>();

  /**
   * Builds this strategy with the given pool.
   * Note: the pool will be internally copied to prevent it from being changed outside.
   */
  public FcfsFixedSizePoolAllocationStrategy(final Collection<String> pool) {
    for (final String body : pool) {
      this.pool.add(body);
    }
  }

  public Integer affectedBodiesCount() {
    return Integer.valueOf(this.affectations.size());
  }

  public Map<Address, String> affectedBodies() {
    return Collections.<Address, String>unmodifiableMap(this.affectations);
  }

  @DefaultValueSource
  public String affectOrGetBody(final Address address, @DefaultValue("io.sarl.airsim.simulation.allocation.AllocationStrategy#AFFECTORGETBODY_0") final Procedure2<Address, String> onAffectation) {
    String name = null;
    boolean _containsKey = this.affectations.containsKey(address);
    if ((!_containsKey)) {
      synchronized (this.pool) {
        boolean _isEmpty = this.pool.isEmpty();
        if (_isEmpty) {
          return null;
        }
        name = this.pool.poll();
      }
      this.affectations.put(address, name);
      onAffectation.apply(address, name);
    } else {
      name = this.affectations.get(address);
    }
    return name;
  }

  @Override
  @Pure
  @SyntheticMember
  public boolean equals(final Object obj) {
    return super.equals(obj);
  }

  @Override
  @Pure
  @SyntheticMember
  public int hashCode() {
    int result = super.hashCode();
    return result;
  }
}
