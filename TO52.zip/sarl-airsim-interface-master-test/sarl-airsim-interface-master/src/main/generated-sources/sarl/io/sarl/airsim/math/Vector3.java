package io.sarl.airsim.math;

import fr.utbm.airsim.api.Vector3r;
import io.sarl.lang.core.annotation.SarlElementType;
import io.sarl.lang.core.annotation.SarlSpecification;
import io.sarl.lang.core.annotation.SyntheticMember;
import java.util.Objects;
import org.eclipse.xtext.xbase.lib.Pure;

/**
 * Represents a 3D vector (immutable)
 * @author Alexandre Lombard
 */
@SarlSpecification("0.13")
@SarlElementType(10)
@SuppressWarnings("all")
public class Vector3 implements Vector<Vector3> {
  /**
   * X coordinate
   */
  public final Float x;

  /**
   * Y coordinate
   */
  public final Float y;

  /**
   * Z coordinate
   */
  public final Float z;

  private final Float squaredNorm;

  private final Float norm;

  /**
   * Builds a null-vector
   */
  public Vector3() {
    this(Float.valueOf(0.0f), Float.valueOf(0.0f), Float.valueOf(0.0f));
  }

  /**
   * The copy constructor of Vector3
   * @param v the vector to copy
   */
  public Vector3(final Vector3r v) {
    this(Float.valueOf(v.getX()), Float.valueOf(v.getY()), Float.valueOf(v.getZ()));
  }

  /**
   * Builds a vector with the given parameters
   * @param x the X coordinate
   * @param y the Y coordinate
   * @param z the Z coordinate
   */
  public Vector3(final Float x, final Float y, final Float z) {
    this.x = x;
    this.y = y;
    this.z = z;
    this.squaredNorm = Float.valueOf((((((x) == null ? 0 : (x).floatValue()) * ((x) == null ? 0 : (x).floatValue())) + (((y) == null ? 0 : (y).floatValue()) * ((y) == null ? 0 : (y).floatValue()))) + (((z) == null ? 0 : (z).floatValue()) * ((z) == null ? 0 : (z).floatValue()))));
    this.norm = Float.valueOf(Double.valueOf(Math.sqrt(((this.squaredNorm) == null ? 0 : (this.squaredNorm).floatValue()))).floatValue());
  }

  /**
   * Getter for X
   * @return X
   */
  @Pure
  public Float getX() {
    return this.x;
  }

  /**
   * Getter for Y
   * @return Y
   */
  @Pure
  public Float getY() {
    return this.y;
  }

  /**
   * Getter for Z
   * @return Z
   */
  @Pure
  public Float getZ() {
    return this.z;
  }

  /**
   * Compute the cross product of this and v
   * @param v the other vector
   * @return the cross product of this and v
   */
  @Pure
  public Vector3 cross(final Vector3 v) {
    return new Vector3(Float.valueOf(((((this.y) == null ? 0 : (this.y).floatValue()) * ((v.z) == null ? 0 : (v.z).floatValue())) - (((this.z) == null ? 0 : (this.z).floatValue()) * ((v.y) == null ? 0 : (v.y).floatValue())))), Float.valueOf(((((this.z) == null ? 0 : (this.z).floatValue()) * ((v.x) == null ? 0 : (v.x).floatValue())) - (((this.x) == null ? 0 : (this.x).floatValue()) * ((v.z) == null ? 0 : (v.z).floatValue())))), Float.valueOf(((((this.x) == null ? 0 : (this.x).floatValue()) * ((v.y) == null ? 0 : (v.y).floatValue())) - (((this.y) == null ? 0 : (this.y).floatValue()) * ((v.x) == null ? 0 : (v.x).floatValue())))));
  }

  /**
   * Computes the projection of a vector v on this
   * @param v the vector to project
   * @return the projection of v on this
   */
  public Vector3 project(final Vector3 v) {
    Float _dot = this.dot(v);
    Float _squaredNorm = this.squaredNorm();
    return this.operator_multiply(Float.valueOf((((_dot) == null ? 0 : (_dot).floatValue()) / ((_squaredNorm) == null ? 0 : (_squaredNorm).floatValue()))), this);
  }

  /**
   * Computes the dot product of this vector and v
   * @param v the other vector
   * @return the dot product
   */
  @Override
  @Pure
  public Float dot(final Vector3 v) {
    return Float.valueOf((((((this.x) == null ? 0 : (this.x).floatValue()) * ((v.x) == null ? 0 : (v.x).floatValue())) + (((this.y) == null ? 0 : (this.y).floatValue()) * ((v.y) == null ? 0 : (v.y).floatValue()))) + (((this.z) == null ? 0 : (this.z).floatValue()) * ((v.z) == null ? 0 : (v.z).floatValue()))));
  }

  /**
   * Operator plus, computes the sum of two vectors (this and v)
   * @param v the vector to add
   * @return the sum of this and v
   */
  @Override
  @Pure
  public Vector3 operator_plus(final Vector3 v) {
    return new Vector3(Float.valueOf((((this.x) == null ? 0 : (this.x).floatValue()) + ((v.x) == null ? 0 : (v.x).floatValue()))), Float.valueOf((((this.y) == null ? 0 : (this.y).floatValue()) + ((v.y) == null ? 0 : (v.y).floatValue()))), Float.valueOf((((this.z) == null ? 0 : (this.z).floatValue()) + ((v.z) == null ? 0 : (v.z).floatValue()))));
  }

  /**
   * Minus function, equivalent to this - v
   * @param v the vector to subtract
   * @return the difference of this and v
   */
  @Override
  @Pure
  public Vector3 operator_minus(final Vector3 v) {
    return new Vector3(Float.valueOf((((this.x) == null ? 0 : (this.x).floatValue()) - ((v.x) == null ? 0 : (v.x).floatValue()))), Float.valueOf((((this.y) == null ? 0 : (this.y).floatValue()) - ((v.y) == null ? 0 : (v.y).floatValue()))), Float.valueOf((((this.z) == null ? 0 : (this.z).floatValue()) - ((v.z) == null ? 0 : (v.z).floatValue()))));
  }

  /**
   * Operator multiply, computes the product of this vector by a scalar
   * @param l the scalar
   * @return the product of this by the given scalar
   */
  @Override
  public Vector3 operator_multiply(final Float l) {
    return new Vector3(Float.valueOf((((this.x) == null ? 0 : (this.x).floatValue()) * ((l) == null ? 0 : (l).floatValue()))), Float.valueOf((((this.y) == null ? 0 : (this.y).floatValue()) * ((l) == null ? 0 : (l).floatValue()))), Float.valueOf((((this.z) == null ? 0 : (this.z).floatValue()) * ((l) == null ? 0 : (l).floatValue()))));
  }

  /**
   * Operator multiply, computes the product of this vector by a scalar
   * @param l the scalar
   * @return the product of this by the given scalar
   */
  @Override
  @Pure
  public Vector3 operator_multiply(final Float l, final Vector3 v) {
    return new Vector3(Float.valueOf((((v.x) == null ? 0 : (v.x).floatValue()) * ((l) == null ? 0 : (l).floatValue()))), Float.valueOf((((v.y) == null ? 0 : (v.y).floatValue()) * ((l) == null ? 0 : (l).floatValue()))), Float.valueOf((((v.z) == null ? 0 : (v.z).floatValue()) * ((l) == null ? 0 : (l).floatValue()))));
  }

  /**
   * Unary minus operator
   */
  @Override
  public Vector3 operator_minus() {
    return new Vector3(Float.valueOf((-((this.x) == null ? 0 : (this.x).floatValue()))), Float.valueOf((-((this.y) == null ? 0 : (this.y).floatValue()))), Float.valueOf((-((this.z) == null ? 0 : (this.z).floatValue()))));
  }

  /**
   * Gets the squared norm of this vector
   * @return the squared norm of this vector
   */
  @Override
  public Float squaredNorm() {
    return this.squaredNorm;
  }

  /**
   * Gets the norm of this vector
   * @return the norm of this vector
   */
  @Override
  public Float norm() {
    return this.norm;
  }

  /**
   * Converts this to a Vector2 (excluding the Z coordinate)
   * @return a Vector2 with (X, Y) coordinates
   */
  @Pure
  public Vector2 toVector2() {
    return new Vector2(this.x, this.y);
  }

  /**
   * Converts this to a Vector2 (excluding the Z coordinate)
   * @return a Vector2 with (X, Y) coordinates
   */
  @Pure
  public Vector2 xy() {
    return this.toVector2();
  }

  /**
   * Gets the String representation of this vector
   * @return a String showing the coordinates of this vector
   */
  @Override
  @Pure
  public String toString() {
    return (((((("[" + this.x) + ", ") + this.y) + ", ") + this.z) + "]");
  }

  @Override
  @Pure
  @SyntheticMember
  public boolean equals(final Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    Vector3 other = (Vector3) obj;
    if (other.x == null) {
      if (this.x != null)
        return false;
    } else if (this.x == null)
      return false;if (other.x != null && Float.floatToIntBits(other.x.floatValue()) != Float.floatToIntBits(this.x.floatValue()))
      return false;
    if (other.y == null) {
      if (this.y != null)
        return false;
    } else if (this.y == null)
      return false;if (other.y != null && Float.floatToIntBits(other.y.floatValue()) != Float.floatToIntBits(this.y.floatValue()))
      return false;
    if (other.z == null) {
      if (this.z != null)
        return false;
    } else if (this.z == null)
      return false;if (other.z != null && Float.floatToIntBits(other.z.floatValue()) != Float.floatToIntBits(this.z.floatValue()))
      return false;
    if (other.squaredNorm == null) {
      if (this.squaredNorm != null)
        return false;
    } else if (this.squaredNorm == null)
      return false;if (other.squaredNorm != null && Float.floatToIntBits(other.squaredNorm.floatValue()) != Float.floatToIntBits(this.squaredNorm.floatValue()))
      return false;
    if (other.norm == null) {
      if (this.norm != null)
        return false;
    } else if (this.norm == null)
      return false;if (other.norm != null && Float.floatToIntBits(other.norm.floatValue()) != Float.floatToIntBits(this.norm.floatValue()))
      return false;
    return super.equals(obj);
  }

  @Override
  @Pure
  @SyntheticMember
  public int hashCode() {
    int result = super.hashCode();
    final int prime = 31;
    result = prime * result + Objects.hashCode(this.x);
    result = prime * result + Objects.hashCode(this.y);
    result = prime * result + Objects.hashCode(this.z);
    result = prime * result + Objects.hashCode(this.squaredNorm);
    result = prime * result + Objects.hashCode(this.norm);
    return result;
  }
}
