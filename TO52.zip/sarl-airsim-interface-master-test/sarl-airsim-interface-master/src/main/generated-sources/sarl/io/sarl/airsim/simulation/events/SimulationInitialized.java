package io.sarl.airsim.simulation.events;

import io.sarl.lang.core.Address;
import io.sarl.lang.core.Event;
import io.sarl.lang.core.annotation.SarlElementType;
import io.sarl.lang.core.annotation.SarlSpecification;
import io.sarl.lang.core.annotation.SyntheticMember;

/**
 * Event emitted when the simulation has been initialized
 * @author Alexandre Lombard
 */
@SarlSpecification("0.13")
@SarlElementType(15)
@SuppressWarnings("all")
public class SimulationInitialized extends Event {
  @SyntheticMember
  public SimulationInitialized() {
    super();
  }

  @SyntheticMember
  public SimulationInitialized(final Address arg0) {
    super(arg0);
  }

  @SyntheticMember
  private static final long serialVersionUID = 588368462L;
}
