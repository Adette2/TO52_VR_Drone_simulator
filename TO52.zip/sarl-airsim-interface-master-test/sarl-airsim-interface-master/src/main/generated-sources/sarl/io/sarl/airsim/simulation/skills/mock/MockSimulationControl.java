package io.sarl.airsim.simulation.skills.mock;

import io.sarl.airsim.simulation.capacities.SimulationControlCapacity;
import io.sarl.api.core.Logging;
import io.sarl.api.core.Schedules;
import io.sarl.lang.core.Agent;
import io.sarl.lang.core.AtomicSkillReference;
import io.sarl.lang.core.Skill;
import io.sarl.lang.core.annotation.DefaultValue;
import io.sarl.lang.core.annotation.DefaultValueSource;
import io.sarl.lang.core.annotation.ImportedCapacityFeature;
import io.sarl.lang.core.annotation.SarlElementType;
import io.sarl.lang.core.annotation.SarlSpecification;
import io.sarl.lang.core.annotation.SyntheticMember;
import org.eclipse.xtext.xbase.lib.Extension;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;
import org.eclipse.xtext.xbase.lib.Pure;

/**
 * Mock for the simulation control implementing the corresponding capacity.
 * Its behavior mainly allows setting the simulation pause state to <code>true</code> or <code>false</code>.
 * simContinueForTime will change the pause state.
 * simPrintLogMessage will use the logging capacity.
 * @author Alexandre Lombard
 */
@SarlSpecification("0.13")
@SarlElementType(22)
@SuppressWarnings("all")
public class MockSimulationControl extends Skill implements SimulationControlCapacity {
  private boolean paused = false;

  private boolean continuing = false;

  public void simContinueForTime(final Float time) {
    synchronized (this) {
      if ((!this.continuing)) {
        final boolean savedPauseState = this.paused;
        this.continuing = true;
        this.paused = false;
        Schedules _$CAPACITY_USE$IO_SARL_API_CORE_SCHEDULES$CALLER = this.$CAPACITY_USE$IO_SARL_API_CORE_SCHEDULES$CALLER();
        final Procedure1<Agent> _function = (Agent it) -> {
          synchronized (this) {
            this.paused = savedPauseState;
            this.continuing = true;
          }
        };
        _$CAPACITY_USE$IO_SARL_API_CORE_SCHEDULES$CALLER.in(Float.valueOf((((time) == null ? 0 : (time).floatValue()) * 1000)).longValue(), _function);
      }
    }
  }

  public void simPause(final Boolean pause) {
    synchronized (this) {
      this.paused = ((pause) == null ? false : (pause).booleanValue());
    }
  }

  public Boolean simIsPaused() {
    synchronized (this) {
      return Boolean.valueOf(this.paused);
    }
  }

  @DefaultValueSource
  public void simPrintLogMessage(final String message, final String messageParam, @DefaultValue("io.sarl.airsim.simulation.capacities.SimulationControlCapacity#SIMPRINTLOGMESSAGE_0") final Integer severity) {
    Logging _$CAPACITY_USE$IO_SARL_API_CORE_LOGGING$CALLER = this.$CAPACITY_USE$IO_SARL_API_CORE_LOGGING$CALLER();
    _$CAPACITY_USE$IO_SARL_API_CORE_LOGGING$CALLER.info(((((message + " ; ") + messageParam) + " ; ") + severity));
  }

  @Extension
  @ImportedCapacityFeature(Logging.class)
  @SyntheticMember
  private transient AtomicSkillReference $CAPACITY_USE$IO_SARL_API_CORE_LOGGING;

  @SyntheticMember
  @Pure
  private Logging $CAPACITY_USE$IO_SARL_API_CORE_LOGGING$CALLER() {
    if (this.$CAPACITY_USE$IO_SARL_API_CORE_LOGGING == null || this.$CAPACITY_USE$IO_SARL_API_CORE_LOGGING.get() == null) {
      this.$CAPACITY_USE$IO_SARL_API_CORE_LOGGING = $getSkill(Logging.class);
    }
    return $castSkill(Logging.class, this.$CAPACITY_USE$IO_SARL_API_CORE_LOGGING);
  }

  @Extension
  @ImportedCapacityFeature(Schedules.class)
  @SyntheticMember
  private transient AtomicSkillReference $CAPACITY_USE$IO_SARL_API_CORE_SCHEDULES;

  @SyntheticMember
  @Pure
  private Schedules $CAPACITY_USE$IO_SARL_API_CORE_SCHEDULES$CALLER() {
    if (this.$CAPACITY_USE$IO_SARL_API_CORE_SCHEDULES == null || this.$CAPACITY_USE$IO_SARL_API_CORE_SCHEDULES.get() == null) {
      this.$CAPACITY_USE$IO_SARL_API_CORE_SCHEDULES = $getSkill(Schedules.class);
    }
    return $castSkill(Schedules.class, this.$CAPACITY_USE$IO_SARL_API_CORE_SCHEDULES);
  }

  @Override
  @Pure
  @SyntheticMember
  public boolean equals(final Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    MockSimulationControl other = (MockSimulationControl) obj;
    if (other.paused != this.paused)
      return false;
    if (other.continuing != this.continuing)
      return false;
    return super.equals(obj);
  }

  @Override
  @Pure
  @SyntheticMember
  public int hashCode() {
    int result = super.hashCode();
    final int prime = 31;
    result = prime * result + Boolean.hashCode(this.paused);
    result = prime * result + Boolean.hashCode(this.continuing);
    return result;
  }

  @SyntheticMember
  public MockSimulationControl() {
    super();
  }

  @SyntheticMember
  public MockSimulationControl(final Agent arg0) {
    super(arg0);
  }
}
