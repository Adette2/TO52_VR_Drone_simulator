package io.sarl.airsim.influences;

import io.sarl.lang.core.Address;
import io.sarl.lang.core.Event;
import io.sarl.lang.core.annotation.SarlElementType;
import io.sarl.lang.core.annotation.SarlSpecification;
import io.sarl.lang.core.annotation.SyntheticMember;

/**
 * Event emitted by an agent when it wants to take off
 * @author Alexandre Lombard
 */
@SarlSpecification("0.13")
@SarlElementType(15)
@SuppressWarnings("all")
public class Takeoff extends Event {
  @SyntheticMember
  public Takeoff() {
    super();
  }

  @SyntheticMember
  public Takeoff(final Address arg0) {
    super(arg0);
  }

  @SyntheticMember
  private static final long serialVersionUID = 588368462L;
}
