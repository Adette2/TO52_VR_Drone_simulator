package io.sarl.airsim.communication;

import fr.utbm.airsim.api.Pose;
import io.sarl.lang.core.Event;
import io.sarl.lang.core.annotation.SarlElementType;
import io.sarl.lang.core.annotation.SarlSpecification;
import io.sarl.lang.core.annotation.SyntheticMember;
import org.eclipse.xtext.xbase.lib.Pure;
import org.eclipse.xtext.xbase.lib.util.ToStringBuilder;

/**
 * Event emitted by agent to notify their pose to the other agents.
 * This event does not directly interact with the simulation
 * @author Alexandre Lombard
 */
@SarlSpecification("0.13")
@SarlElementType(15)
@SuppressWarnings("all")
public class NotifyPose extends Event {
  public final Pose pose;

  public NotifyPose(final Pose pose) {
    this.pose = pose;
  }

  @Override
  @Pure
  @SyntheticMember
  public boolean equals(final Object obj) {
    return super.equals(obj);
  }

  @Override
  @Pure
  @SyntheticMember
  public int hashCode() {
    int result = super.hashCode();
    return result;
  }

  /**
   * Returns a String representation of the NotifyPose event's attributes only.
   */
  @SyntheticMember
  @Pure
  protected void toString(final ToStringBuilder builder) {
    super.toString(builder);
    builder.add("pose", this.pose);
  }

  @SyntheticMember
  private static final long serialVersionUID = 3209315254L;
}
