package io.sarl.airsim.simulation.capacities;

import io.sarl.lang.core.AgentTrait;
import io.sarl.lang.core.Capacity;
import io.sarl.lang.core.annotation.DefaultValue;
import io.sarl.lang.core.annotation.DefaultValueSource;
import io.sarl.lang.core.annotation.DefaultValueUse;
import io.sarl.lang.core.annotation.SarlElementType;
import io.sarl.lang.core.annotation.SarlSourceCode;
import io.sarl.lang.core.annotation.SarlSpecification;
import io.sarl.lang.core.annotation.SyntheticMember;
import org.eclipse.xtext.xbase.lib.Pure;

/**
 * Capacity to control the simulation
 * @author Alexandre Lombard
 */
@SarlSpecification("0.13")
@SarlElementType(20)
@SuppressWarnings("all")
public interface SimulationControlCapacity extends Capacity {
  /**
   * Continue the simulation for the given amount of time
   * @param time the time in seconds
   */
  void simContinueForTime(final Float time);

  /**
   * Pauses (or unpauses the simulation)
   * @param pause <code>true</code> to pause the simulation, <code>false</code> to unpause the simulation
   */
  void simPause(final Boolean pause);

  /**
   * Returns <code>true</code> if the simulation is paused, <code>false</code> otherwise
   * @return <code>true</code> if the simulation is paused, <code>false</code> otherwise
   */
  Boolean simIsPaused();

  /**
   * Prints a message in the log of the simulation environment
   * @param message the message
   * @param messageParam the message parameters
   * @param severity the severity (default is 0)
   */
  @DefaultValueSource
  void simPrintLogMessage(final String message, final String messageParam, @DefaultValue("io.sarl.airsim.simulation.capacities.SimulationControlCapacity#SIMPRINTLOGMESSAGE_0") final Integer severity);

  /**
   * Default value for the parameter severity
   */
  @Pure
  @SyntheticMember
  @SarlSourceCode("0")
  default Integer $DEFAULT_VALUE$SIMPRINTLOGMESSAGE_0() {
    return Integer.valueOf(0);
  }

  /**
   * Prints a message in the log of the simulation environment
   * @param message the message
   * @param messageParam the message parameters
   * @optionalparam severity the severity (default is 0)
   */
  @DefaultValueUse("java.lang.String,java.lang.String,java.lang.Integer")
  @SyntheticMember
  default void simPrintLogMessage(final String message, final String messageParam) {
    simPrintLogMessage(message, messageParam, $DEFAULT_VALUE$SIMPRINTLOGMESSAGE_0());
  }

  /**
   * @ExcludeFromApidoc
   */
  class ContextAwareCapacityWrapper<C extends SimulationControlCapacity> extends Capacity.ContextAwareCapacityWrapper<C> implements SimulationControlCapacity {
    public ContextAwareCapacityWrapper(final C capacity, final AgentTrait caller) {
      super(capacity, caller);
    }

    public void simContinueForTime(final Float time) {
      try {
        ensureCallerInLocalThread();
        this.capacity.simContinueForTime(time);
      } finally {
        resetCallerInLocalThread();
      }
    }

    public void simPause(final Boolean pause) {
      try {
        ensureCallerInLocalThread();
        this.capacity.simPause(pause);
      } finally {
        resetCallerInLocalThread();
      }
    }

    public Boolean simIsPaused() {
      try {
        ensureCallerInLocalThread();
        return this.capacity.simIsPaused();
      } finally {
        resetCallerInLocalThread();
      }
    }

    public void simPrintLogMessage(final String message, final String messageParam, final Integer severity) {
      try {
        ensureCallerInLocalThread();
        this.capacity.simPrintLogMessage(message, messageParam, severity);
      } finally {
        resetCallerInLocalThread();
      }
    }

    public void simPrintLogMessage(final String message, final String messageParam) {
      try {
        ensureCallerInLocalThread();
        this.capacity.simPrintLogMessage(message, messageParam);
      } finally {
        resetCallerInLocalThread();
      }
    }
  }
}
