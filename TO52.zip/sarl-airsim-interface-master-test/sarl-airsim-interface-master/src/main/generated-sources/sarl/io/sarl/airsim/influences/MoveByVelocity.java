package io.sarl.airsim.influences;

import io.sarl.airsim.math.Vector3;
import io.sarl.lang.core.Event;
import io.sarl.lang.core.annotation.SarlElementType;
import io.sarl.lang.core.annotation.SarlSpecification;
import io.sarl.lang.core.annotation.SyntheticMember;
import java.util.Objects;
import org.eclipse.xtext.xbase.lib.Pure;
import org.eclipse.xtext.xbase.lib.util.ToStringBuilder;

/**
 * Event emitted by an agent when it wants to move
 * @author Alexandre Lombard
 */
@SarlSpecification("0.13")
@SarlElementType(15)
@SuppressWarnings("all")
public class MoveByVelocity extends Event {
  public final Float vx;

  public final Float vy;

  public final Float vz;

  public final Float duration;

  /**
   * Builds a move by velocity command
   * @param vx the linear velocity on the X axis
   * @param vy the linear velocity on the Y axis
   * @param vz the linear velocity on the Z axis
   * @param duration the duration of the application of the velocity
   */
  public MoveByVelocity(final Float vx, final Float vy, final Float vz, final Float duration) {
    this.vx = vx;
    this.vy = vy;
    this.vz = vz;
    this.duration = duration;
  }

  /**
   * Builds a move by velocity command
   * @param v the velocity vector
   * @param duration the duration of the application of the velocity
   */
  public MoveByVelocity(final Vector3 v, final Float duration) {
    this(v.x, v.y, v.z, duration);
  }

  @Override
  @Pure
  @SyntheticMember
  public boolean equals(final Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    MoveByVelocity other = (MoveByVelocity) obj;
    if (other.vx == null) {
      if (this.vx != null)
        return false;
    } else if (this.vx == null)
      return false;if (other.vx != null && Float.floatToIntBits(other.vx.floatValue()) != Float.floatToIntBits(this.vx.floatValue()))
      return false;
    if (other.vy == null) {
      if (this.vy != null)
        return false;
    } else if (this.vy == null)
      return false;if (other.vy != null && Float.floatToIntBits(other.vy.floatValue()) != Float.floatToIntBits(this.vy.floatValue()))
      return false;
    if (other.vz == null) {
      if (this.vz != null)
        return false;
    } else if (this.vz == null)
      return false;if (other.vz != null && Float.floatToIntBits(other.vz.floatValue()) != Float.floatToIntBits(this.vz.floatValue()))
      return false;
    if (other.duration == null) {
      if (this.duration != null)
        return false;
    } else if (this.duration == null)
      return false;if (other.duration != null && Float.floatToIntBits(other.duration.floatValue()) != Float.floatToIntBits(this.duration.floatValue()))
      return false;
    return super.equals(obj);
  }

  @Override
  @Pure
  @SyntheticMember
  public int hashCode() {
    int result = super.hashCode();
    final int prime = 31;
    result = prime * result + Objects.hashCode(this.vx);
    result = prime * result + Objects.hashCode(this.vy);
    result = prime * result + Objects.hashCode(this.vz);
    result = prime * result + Objects.hashCode(this.duration);
    return result;
  }

  /**
   * Returns a String representation of the MoveByVelocity event's attributes only.
   */
  @SyntheticMember
  @Pure
  protected void toString(final ToStringBuilder builder) {
    super.toString(builder);
    builder.add("vx", this.vx);
    builder.add("vy", this.vy);
    builder.add("vz", this.vz);
    builder.add("duration", this.duration);
  }

  @SyntheticMember
  private static final long serialVersionUID = -5165713446L;
}
