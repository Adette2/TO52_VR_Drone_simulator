package io.sarl.airsim.simulation.capacities;

import fr.utbm.airsim.api.MultirotorState;
import io.sarl.lang.core.AgentTrait;
import io.sarl.lang.core.Capacity;
import io.sarl.lang.core.annotation.SarlElementType;
import io.sarl.lang.core.annotation.SarlSpecification;
import org.eclipse.xtext.xbase.lib.Pure;

/**
 * Capacity to perceive the state of a multirotor object
 * @author Alexandre Lombard
 */
@FunctionalInterface
@SarlSpecification("0.13")
@SarlElementType(20)
@SuppressWarnings("all")
public interface MultirotorSimulationPerceptionCapacity extends Capacity {
  /**
   * Gets the state of the given multirotor object
   * @param vehicleName the name of the vehicle
   * @return the state of the vehicle
   */
  @Pure
  MultirotorState getMultirotorState(final String vehicleName);

  /**
   * @ExcludeFromApidoc
   */
  class ContextAwareCapacityWrapper<C extends MultirotorSimulationPerceptionCapacity> extends Capacity.ContextAwareCapacityWrapper<C> implements MultirotorSimulationPerceptionCapacity {
    public ContextAwareCapacityWrapper(final C capacity, final AgentTrait caller) {
      super(capacity, caller);
    }

    public MultirotorState getMultirotorState(final String vehicleName) {
      try {
        ensureCallerInLocalThread();
        return this.capacity.getMultirotorState(vehicleName);
      } finally {
        resetCallerInLocalThread();
      }
    }
  }
}
