package io.sarl.airsim.simulation.skills.airsim;

import fr.utbm.airsim.api.RpcLibClientBase;
import io.sarl.airsim.simulation.capacities.SimulationControlCapacity;
import io.sarl.lang.core.Skill;
import io.sarl.lang.core.annotation.DefaultValue;
import io.sarl.lang.core.annotation.DefaultValueSource;
import io.sarl.lang.core.annotation.SarlElementType;
import io.sarl.lang.core.annotation.SarlSpecification;
import io.sarl.lang.core.annotation.SyntheticMember;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.Pure;
import org.msgpack.rpc.Client;
import org.msgpack.rpc.loop.EventLoop;

/**
 * Simulation control capacity relying on AirSim
 * @author Alexandre Lombard
 */
@SarlSpecification("0.13")
@SarlElementType(22)
@SuppressWarnings("all")
public class AirSimSimulationControl extends Skill implements SimulationControlCapacity {
  private final EventLoop loop = EventLoop.defaultEventLoop();

  private final Client rpcClient;

  private final RpcLibClientBase rpcLibClient;

  public AirSimSimulationControl() {
    this("127.0.0.1", Integer.valueOf(41451));
  }

  public AirSimSimulationControl(final String ipAddress, final Integer port) {
    try {
      Client _client = new Client(ipAddress, ((port) == null ? 0 : (port).intValue()), this.loop);
      this.rpcClient = _client;
      this.rpcLibClient = this.rpcClient.<RpcLibClientBase>proxy(RpcLibClientBase.class);
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }

  public void install() {
  }

  public void uninstall() {
  }

  @Override
  public void simContinueForTime(final Float time) {
    synchronized (this.rpcLibClient) {
      this.rpcLibClient.simContinueForTime(((time) == null ? 0 : (time).floatValue()));
    }
  }

  @Override
  public void simPause(final Boolean pause) {
    synchronized (this.rpcLibClient) {
      this.rpcLibClient.simPause(((pause) == null ? false : (pause).booleanValue()));
    }
  }

  @Override
  public Boolean simIsPaused() {
    synchronized (this.rpcLibClient) {
      return Boolean.valueOf(this.rpcLibClient.simIsPaused());
    }
  }

  @DefaultValueSource
  @Override
  public void simPrintLogMessage(final String message, final String messageParam, @DefaultValue("io.sarl.airsim.simulation.capacities.SimulationControlCapacity#SIMPRINTLOGMESSAGE_0") final Integer severity) {
    synchronized (this.rpcLibClient) {
      this.rpcLibClient.simPrintLogMessage(message, messageParam, ((severity) == null ? 0 : (severity).intValue()));
    }
  }

  @Override
  @Pure
  @SyntheticMember
  public boolean equals(final Object obj) {
    return super.equals(obj);
  }

  @Override
  @Pure
  @SyntheticMember
  public int hashCode() {
    int result = super.hashCode();
    return result;
  }
}
