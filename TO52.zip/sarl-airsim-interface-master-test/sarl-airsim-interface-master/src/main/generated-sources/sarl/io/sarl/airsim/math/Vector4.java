package io.sarl.airsim.math;

import io.sarl.lang.core.annotation.SarlElementType;
import io.sarl.lang.core.annotation.SarlSpecification;
import io.sarl.lang.core.annotation.SyntheticMember;
import java.util.Objects;
import org.eclipse.xtext.xbase.lib.Pure;

/**
 * Represents a 4D vector (immutable)
 * @author Alexandre Lombard
 */
@SarlSpecification("0.13")
@SarlElementType(10)
@SuppressWarnings("all")
public class Vector4 implements Vector<Vector4> {
  /**
   * X coordinate
   */
  public final Float x;

  /**
   * Y coordinate
   */
  public final Float y;

  /**
   * Z coordinate
   */
  public final Float z;

  /**
   * T coordinate
   */
  public final Float t;

  private final Float squaredNorm;

  private final Float norm;

  /**
   * Builds a null-vector
   */
  public Vector4() {
    this(Float.valueOf(0.0f), Float.valueOf(0.0f), Float.valueOf(0.0f), Float.valueOf(0.0f));
  }

  /**
   * Builds a vector with the given parameters
   * @param x the X coordinate
   * @param y the Y coordinate
   * @param z the Z coordinate
   * @param t the T coordinate
   */
  public Vector4(final Float x, final Float y, final Float z, final Float t) {
    this.x = x;
    this.y = y;
    this.z = z;
    this.t = t;
    this.squaredNorm = Float.valueOf(((((((x) == null ? 0 : (x).floatValue()) * ((x) == null ? 0 : (x).floatValue())) + (((y) == null ? 0 : (y).floatValue()) * ((y) == null ? 0 : (y).floatValue()))) + (((z) == null ? 0 : (z).floatValue()) * ((z) == null ? 0 : (z).floatValue()))) + (((t) == null ? 0 : (t).floatValue()) * ((t) == null ? 0 : (t).floatValue()))));
    this.norm = Float.valueOf(Double.valueOf(Math.sqrt(((this.squaredNorm) == null ? 0 : (this.squaredNorm).floatValue()))).floatValue());
  }

  /**
   * Getter for X
   * @return X
   */
  @Pure
  public Float getX() {
    return this.x;
  }

  /**
   * Getter for Y
   * @return Y
   */
  @Pure
  public Float getY() {
    return this.y;
  }

  /**
   * Getter for Z
   * @return Z
   */
  @Pure
  public Float getZ() {
    return this.z;
  }

  /**
   * Getter for T
   * @return T
   */
  @Pure
  public Float getT() {
    return this.t;
  }

  /**
   * Operator plus, computes the sum of two vectors (this and v)
   * @param v the vector to add
   * @return the sum of this and v
   */
  @Override
  @Pure
  public Vector4 operator_plus(final Vector4 v) {
    return new Vector4(Float.valueOf((((this.x) == null ? 0 : (this.x).floatValue()) + ((v.x) == null ? 0 : (v.x).floatValue()))), Float.valueOf((((this.y) == null ? 0 : (this.y).floatValue()) + ((v.y) == null ? 0 : (v.y).floatValue()))), Float.valueOf((((this.z) == null ? 0 : (this.z).floatValue()) + ((v.z) == null ? 0 : (v.z).floatValue()))), Float.valueOf((((this.t) == null ? 0 : (this.t).floatValue()) + ((v.t) == null ? 0 : (v.t).floatValue()))));
  }

  /**
   * Operator minus, computes the difference of two vectors (this and v)
   * @param v the vector to subtract
   * @return the difference of this and v
   */
  @Override
  @Pure
  public Vector4 operator_minus(final Vector4 v) {
    return new Vector4(Float.valueOf((((this.x) == null ? 0 : (this.x).floatValue()) - ((v.x) == null ? 0 : (v.x).floatValue()))), Float.valueOf((((this.y) == null ? 0 : (this.y).floatValue()) - ((v.y) == null ? 0 : (v.y).floatValue()))), Float.valueOf((((this.z) == null ? 0 : (this.z).floatValue()) - ((v.z) == null ? 0 : (v.z).floatValue()))), Float.valueOf((((this.t) == null ? 0 : (this.t).floatValue()) - ((v.t) == null ? 0 : (v.t).floatValue()))));
  }

  /**
   * Operator multiply, computes the product of this vector by a scalar
   * @param l the scalar
   * @return the product of this by the given scalar
   */
  @Override
  public Vector4 operator_multiply(final Float l) {
    return new Vector4(Float.valueOf((((this.x) == null ? 0 : (this.x).floatValue()) * ((l) == null ? 0 : (l).floatValue()))), Float.valueOf((((this.y) == null ? 0 : (this.y).floatValue()) * ((l) == null ? 0 : (l).floatValue()))), Float.valueOf((((this.z) == null ? 0 : (this.z).floatValue()) * ((l) == null ? 0 : (l).floatValue()))), Float.valueOf((((this.t) == null ? 0 : (this.t).floatValue()) * ((l) == null ? 0 : (l).floatValue()))));
  }

  /**
   * Operator multiply, computes the product of this vector by a scalar
   * @param l the scalar
   * @return the product of this by the given scalar
   */
  @Override
  @Pure
  public Vector4 operator_multiply(final Float l, final Vector4 v) {
    return new Vector4(Float.valueOf((((v.x) == null ? 0 : (v.x).floatValue()) * ((l) == null ? 0 : (l).floatValue()))), Float.valueOf((((v.y) == null ? 0 : (v.y).floatValue()) * ((l) == null ? 0 : (l).floatValue()))), Float.valueOf((((v.z) == null ? 0 : (v.z).floatValue()) * ((l) == null ? 0 : (l).floatValue()))), Float.valueOf((((v.t) == null ? 0 : (v.t).floatValue()) * ((l) == null ? 0 : (l).floatValue()))));
  }

  /**
   * Unary minus operator
   */
  @Override
  public Vector4 operator_minus() {
    return new Vector4(Float.valueOf((-((this.x) == null ? 0 : (this.x).floatValue()))), Float.valueOf((-((this.y) == null ? 0 : (this.y).floatValue()))), Float.valueOf((-((this.z) == null ? 0 : (this.z).floatValue()))), Float.valueOf((-((this.t) == null ? 0 : (this.t).floatValue()))));
  }

  /**
   * Computes the dot product of this vector and v
   * @param v the other vector
   * @return the dot product
   */
  @Override
  @Pure
  public Float dot(final Vector4 v) {
    return Float.valueOf(((((((this.x) == null ? 0 : (this.x).floatValue()) * ((v.x) == null ? 0 : (v.x).floatValue())) + (((this.y) == null ? 0 : (this.y).floatValue()) * ((v.y) == null ? 0 : (v.y).floatValue()))) + (((this.z) == null ? 0 : (this.z).floatValue()) * ((v.z) == null ? 0 : (v.z).floatValue()))) + (((this.t) == null ? 0 : (this.t).floatValue()) * ((v.t) == null ? 0 : (v.t).floatValue()))));
  }

  /**
   * Gets the squared norm of this vector
   * @return the squared norm of this vector
   */
  @Override
  public Float squaredNorm() {
    return this.squaredNorm;
  }

  /**
   * Gets the norm of this vector
   * @return the norm of this vector
   */
  @Override
  public Float norm() {
    return this.norm;
  }

  /**
   * Converts this to a Vector3 (excluding the T coordinate)
   * @return a Vector3 with (X, Y, Z) coordinates
   */
  @Pure
  public Vector3 toVector3() {
    return new Vector3(this.x, this.y, this.z);
  }

  /**
   * Converts this to a Vector3 (excluding the T coordinate)
   * @return a Vector3 with (X, Y, Z) coordinates
   */
  @Pure
  public Vector3 xyz() {
    return this.toVector3();
  }

  /**
   * Converts this to a Vector2 (excluding the Z, T coordinate)
   * @return a Vector2 with (X, Y) coordinates
   */
  @Pure
  public Vector2 toVector2() {
    return new Vector2(this.x, this.y);
  }

  /**
   * Converts this to a Vector2 (excluding the Z, T coordinate)
   * @return a Vector2 with (X, Y) coordinates
   */
  @Pure
  public Vector2 xy() {
    return this.toVector2();
  }

  /**
   * Gets the String representation of this vector
   * @return a String showing the coordinates of this vector
   */
  @Override
  @Pure
  public String toString() {
    return (((((((("[" + this.x) + ", ") + this.y) + ", ") + this.z) + ", ") + this.t) + "]");
  }

  @Override
  @Pure
  @SyntheticMember
  public boolean equals(final Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    Vector4 other = (Vector4) obj;
    if (other.x == null) {
      if (this.x != null)
        return false;
    } else if (this.x == null)
      return false;if (other.x != null && Float.floatToIntBits(other.x.floatValue()) != Float.floatToIntBits(this.x.floatValue()))
      return false;
    if (other.y == null) {
      if (this.y != null)
        return false;
    } else if (this.y == null)
      return false;if (other.y != null && Float.floatToIntBits(other.y.floatValue()) != Float.floatToIntBits(this.y.floatValue()))
      return false;
    if (other.z == null) {
      if (this.z != null)
        return false;
    } else if (this.z == null)
      return false;if (other.z != null && Float.floatToIntBits(other.z.floatValue()) != Float.floatToIntBits(this.z.floatValue()))
      return false;
    if (other.t == null) {
      if (this.t != null)
        return false;
    } else if (this.t == null)
      return false;if (other.t != null && Float.floatToIntBits(other.t.floatValue()) != Float.floatToIntBits(this.t.floatValue()))
      return false;
    if (other.squaredNorm == null) {
      if (this.squaredNorm != null)
        return false;
    } else if (this.squaredNorm == null)
      return false;if (other.squaredNorm != null && Float.floatToIntBits(other.squaredNorm.floatValue()) != Float.floatToIntBits(this.squaredNorm.floatValue()))
      return false;
    if (other.norm == null) {
      if (this.norm != null)
        return false;
    } else if (this.norm == null)
      return false;if (other.norm != null && Float.floatToIntBits(other.norm.floatValue()) != Float.floatToIntBits(this.norm.floatValue()))
      return false;
    return super.equals(obj);
  }

  @Override
  @Pure
  @SyntheticMember
  public int hashCode() {
    int result = super.hashCode();
    final int prime = 31;
    result = prime * result + Objects.hashCode(this.x);
    result = prime * result + Objects.hashCode(this.y);
    result = prime * result + Objects.hashCode(this.z);
    result = prime * result + Objects.hashCode(this.t);
    result = prime * result + Objects.hashCode(this.squaredNorm);
    result = prime * result + Objects.hashCode(this.norm);
    return result;
  }
}
