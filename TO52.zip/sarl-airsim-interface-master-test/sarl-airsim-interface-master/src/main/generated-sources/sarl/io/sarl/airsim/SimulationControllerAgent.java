package io.sarl.airsim;

import com.google.common.base.Objects;
import fr.utbm.airsim.api.KinematicsState;
import fr.utbm.airsim.api.MultirotorClientInterface;
import fr.utbm.airsim.api.MultirotorState;
import fr.utbm.airsim.api.Pose;
import io.sarl.airsim.influences.MoveByVelocity;
import io.sarl.airsim.influences.Takeoff;
import io.sarl.airsim.perceptions.MultirotorStatePerception;
import io.sarl.airsim.perceptions.sim.SimGroundTruthKinematicsPerception;
import io.sarl.airsim.perceptions.sim.SimPosePerception;
import io.sarl.airsim.simulation.allocation.FcfsFixedSizePoolAllocationStrategy;
import io.sarl.airsim.simulation.capacities.MultirotorSimulationControlCapacity;
import io.sarl.airsim.simulation.capacities.MultirotorSimulationPerceptionCapacity;
import io.sarl.airsim.simulation.capacities.SimulationControlCapacity;
import io.sarl.airsim.simulation.capacities.SimulationPerceptionCapacity;
import io.sarl.airsim.simulation.events.SimulationInitialized;
import io.sarl.airsim.simulation.influence.BatchedInfluenceReactionStrategy;
import io.sarl.airsim.simulation.scheduling.FixedStepBlockingSimulationStrategy;
import io.sarl.airsim.simulation.scheduling.SimulationStrategy;
import io.sarl.airsim.simulation.skills.airsim.AirSimMultirotorControl;
import io.sarl.airsim.simulation.skills.airsim.AirSimMultirotorSimulationPerception;
import io.sarl.airsim.simulation.skills.airsim.AirSimSimulationControl;
import io.sarl.airsim.simulation.skills.airsim.AirSimSimulationPerception;
import io.sarl.airsim.utils.ActiveWaitLock;
import io.sarl.api.core.DefaultContextInteractions;
import io.sarl.api.core.Initialize;
import io.sarl.api.core.Logging;
import io.sarl.api.core.Schedules;
import io.sarl.lang.core.Address;
import io.sarl.lang.core.Agent;
import io.sarl.lang.core.AtomicSkillReference;
import io.sarl.lang.core.DynamicSkillProvider;
import io.sarl.lang.core.Event;
import io.sarl.lang.core.Scope;
import io.sarl.lang.core.annotation.ImportedCapacityFeature;
import io.sarl.lang.core.annotation.PerceptGuardEvaluator;
import io.sarl.lang.core.annotation.SarlElementType;
import io.sarl.lang.core.annotation.SarlSpecification;
import io.sarl.lang.core.annotation.SyntheticMember;
import io.sarl.lang.core.util.SerializableProxy;
import java.io.ObjectStreamException;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Set;
import java.util.UUID;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import javax.inject.Inject;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.Extension;
import org.eclipse.xtext.xbase.lib.Functions.Function0;
import org.eclipse.xtext.xbase.lib.Functions.Function2;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure0;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure2;
import org.eclipse.xtext.xbase.lib.Pure;
import org.msgpack.rpc.Client;
import org.msgpack.rpc.loop.EventLoop;

/**
 * Agent in charge of controlling the simulation, transmitting the influences and
 * dispatching the perceptions .
 * This agent has basically 3 main roles and capacities:
 * - Managing the propagation of perceptions and influences
 * - Managing the simulation schedule
 * - Managing the affectation of bodies to agents
 * @author Alexandre Lombard
 */
@SarlSpecification("0.13")
@SarlElementType(19)
@SuppressWarnings("all")
public class SimulationControllerAgent extends Agent {
  /**
   * The simulation step
   */
  private final float simulationStepMs = 200.0f;

  private final LinkedList<String> pool = CollectionLiterals.<String>newLinkedList("S0", "S1", "S2");

  /**
   * "S3", "S4", "S5", "S6", "S7", "S8", "S9"
   */
  private final FcfsFixedSizePoolAllocationStrategy affectationStrategy = new FcfsFixedSizePoolAllocationStrategy(
    ((Function0<LinkedList<String>>) () -> {
      final LinkedList<String> pool = this.pool;
      Collections.shuffle(pool);
      return pool;
    }).apply());

  private SimulationStrategy simulationStrategy;

  /**
   * Perceptions are propagated as soon as they are received, influences as soon as every one has sent one and eventually if the delay is respected
   */
  private BatchedInfluenceReactionStrategy influenceReactionStrategy;

  private final EventLoop loop = EventLoop.defaultEventLoop();

  private final Client rpcClient = new Function0<Client>() {
    @Override
    public Client apply() {
      try {
        Client _client = new Client("127.0.0.1", 41451, SimulationControllerAgent.this.loop);
        return _client;
      } catch (Throwable _e) {
        throw Exceptions.sneakyThrow(_e);
      }
    }
  }.apply();

  private final MultirotorClientInterface multirotorClient = this.rpcClient.<MultirotorClientInterface>proxy(MultirotorClientInterface.class);

  private void $behaviorUnit$Initialize$0(final Initialize occurrence) {
    AirSimSimulationControl _airSimSimulationControl = new AirSimSimulationControl();
    this.<AirSimSimulationControl>setSkill(_airSimSimulationControl, SimulationControlCapacity.class);
    AirSimMultirotorControl _airSimMultirotorControl = new AirSimMultirotorControl();
    this.<AirSimMultirotorControl>setSkill(_airSimMultirotorControl, MultirotorSimulationControlCapacity.class);
    AirSimSimulationPerception _airSimSimulationPerception = new AirSimSimulationPerception();
    this.<AirSimSimulationPerception>setSkill(_airSimSimulationPerception, SimulationPerceptionCapacity.class);
    AirSimMultirotorSimulationPerception _airSimMultirotorSimulationPerception = new AirSimMultirotorSimulationPerception();
    this.<AirSimMultirotorSimulationPerception>setSkill(_airSimMultirotorSimulationPerception, MultirotorSimulationPerceptionCapacity.class);
    final Consumer<String> _function = (String it) -> {
      MultirotorSimulationControlCapacity _$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_MULTIROTORSIMULATIONCONTROLCAPACITY$CALLER = this.$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_MULTIROTORSIMULATIONCONTROLCAPACITY$CALLER();
      _$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_MULTIROTORSIMULATIONCONTROLCAPACITY$CALLER.enableControl(it);
    };
    this.pool.forEach(_function);
    SimulationControlCapacity _$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_SIMULATIONCONTROLCAPACITY$CALLER = this.$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_SIMULATIONCONTROLCAPACITY$CALLER();
    _$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_SIMULATIONCONTROLCAPACITY$CALLER.simPause(Boolean.valueOf(true));
    final ActiveWaitLock influencesPropagated = new ActiveWaitLock();
    final Function2<Long, Collection<Address>, Boolean> _function_1 = (Long t, Collection<Address> p) -> {
      return Boolean.valueOf(true);
    };
    final Function2<Long, Collection<Address>, Boolean> _function_2 = (Long t, Collection<Address> i) -> {
      int _size = i.size();
      Integer _affectedBodiesCount = this.affectationStrategy.affectedBodiesCount();
      return Boolean.valueOf((_size >= _affectedBodiesCount.doubleValue()));
    };
    BatchedInfluenceReactionStrategy _batchedInfluenceReactionStrategy = new BatchedInfluenceReactionStrategy(_function_1, _function_2, 2, false);
    this.influenceReactionStrategy = _batchedInfluenceReactionStrategy;
    final Procedure0 _function_3 = () -> {
      Logging _$CAPACITY_USE$IO_SARL_API_CORE_LOGGING$CALLER = this.$CAPACITY_USE$IO_SARL_API_CORE_LOGGING$CALLER();
      _$CAPACITY_USE$IO_SARL_API_CORE_LOGGING$CALLER.debug("Influences propagated...");
      influencesPropagated.unlock();
    };
    this.influenceReactionStrategy.onInfluencesPropagated(_function_3);
    final Procedure1<FixedStepBlockingSimulationStrategy.FixedStepBlockingSimulationStrategyBuilder> _function_4 = (FixedStepBlockingSimulationStrategy.FixedStepBlockingSimulationStrategyBuilder it) -> {
      final Procedure0 _function_5 = () -> {
        this.retrievePerceptions();
      };
      it.retrievePerceptionsBy = _function_5;
      final Function0<Boolean> _function_6 = () -> {
        boolean _isLocked = influencesPropagated.isLocked();
        return Boolean.valueOf((!_isLocked));
      };
      it.canContinueIf = _function_6;
      final Procedure0 _function_7 = () -> {
        Logging _$CAPACITY_USE$IO_SARL_API_CORE_LOGGING$CALLER = this.$CAPACITY_USE$IO_SARL_API_CORE_LOGGING$CALLER();
        _$CAPACITY_USE$IO_SARL_API_CORE_LOGGING$CALLER.debug("Continuing simulation (begin)...");
        SimulationControlCapacity _$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_SIMULATIONCONTROLCAPACITY$CALLER_1 = this.$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_SIMULATIONCONTROLCAPACITY$CALLER();
        _$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_SIMULATIONCONTROLCAPACITY$CALLER_1.simContinueForTime(Float.valueOf((this.simulationStepMs / 1000.0f)));
        influencesPropagated.lock();
        Logging _$CAPACITY_USE$IO_SARL_API_CORE_LOGGING$CALLER_1 = this.$CAPACITY_USE$IO_SARL_API_CORE_LOGGING$CALLER();
        _$CAPACITY_USE$IO_SARL_API_CORE_LOGGING$CALLER_1.debug("Continuing simulation (end)...");
      };
      it.continueSimulationBy = _function_7;
    };
    this.simulationStrategy = FixedStepBlockingSimulationStrategy.fixedStepBlockingSimulationStrategy(_function_4);
    Schedules _$CAPACITY_USE$IO_SARL_API_CORE_SCHEDULES$CALLER = this.$CAPACITY_USE$IO_SARL_API_CORE_SCHEDULES$CALLER();
    final Procedure1<Agent> _function_5 = (Agent it) -> {
      this.simulationStrategy.loop();
    };
    _$CAPACITY_USE$IO_SARL_API_CORE_SCHEDULES$CALLER.atFixedDelay(Float.valueOf(this.simulationStepMs).longValue(), _function_5);
    Schedules _$CAPACITY_USE$IO_SARL_API_CORE_SCHEDULES$CALLER_1 = this.$CAPACITY_USE$IO_SARL_API_CORE_SCHEDULES$CALLER();
    final Procedure1<Agent> _function_6 = (Agent it) -> {
      Logging _$CAPACITY_USE$IO_SARL_API_CORE_LOGGING$CALLER = this.$CAPACITY_USE$IO_SARL_API_CORE_LOGGING$CALLER();
      _$CAPACITY_USE$IO_SARL_API_CORE_LOGGING$CALLER.info("Sending the initialized simulation signal");
      DefaultContextInteractions _$CAPACITY_USE$IO_SARL_API_CORE_DEFAULTCONTEXTINTERACTIONS$CALLER = this.$CAPACITY_USE$IO_SARL_API_CORE_DEFAULTCONTEXTINTERACTIONS$CALLER();
      SimulationInitialized _simulationInitialized = new SimulationInitialized();
      _$CAPACITY_USE$IO_SARL_API_CORE_DEFAULTCONTEXTINTERACTIONS$CALLER.emit(_simulationInitialized);
    };
    _$CAPACITY_USE$IO_SARL_API_CORE_SCHEDULES$CALLER_1.in(2000, _function_6);
  }

  private void $behaviorUnit$Takeoff$1(final Takeoff occurrence) {
    final Procedure2<Address, String> _function = (Address a, String n) -> {
      this.onAffectation(a, n);
    };
    final String body = this.affectationStrategy.affectOrGetBody(occurrence.getSource(), _function);
    final Procedure0 _function_1 = () -> {
      Logging _$CAPACITY_USE$IO_SARL_API_CORE_LOGGING$CALLER = this.$CAPACITY_USE$IO_SARL_API_CORE_LOGGING$CALLER();
      _$CAPACITY_USE$IO_SARL_API_CORE_LOGGING$CALLER.info(("Propagation of takeoff for " + body));
      MultirotorSimulationControlCapacity _$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_MULTIROTORSIMULATIONCONTROLCAPACITY$CALLER = this.$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_MULTIROTORSIMULATIONCONTROLCAPACITY$CALLER();
      _$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_MULTIROTORSIMULATIONCONTROLCAPACITY$CALLER.takeOff(body);
    };
    this.influenceReactionStrategy.influenceReceived(occurrence.getSource(), _function_1);
  }

  private void $behaviorUnit$MoveByVelocity$2(final MoveByVelocity occurrence) {
    Logging _$CAPACITY_USE$IO_SARL_API_CORE_LOGGING$CALLER = this.$CAPACITY_USE$IO_SARL_API_CORE_LOGGING$CALLER();
    _$CAPACITY_USE$IO_SARL_API_CORE_LOGGING$CALLER.debug("MoveByVelocity (begin)");
    final Procedure2<Address, String> _function = (Address a, String n) -> {
      this.onAffectation(a, n);
    };
    final String body = this.affectationStrategy.affectOrGetBody(occurrence.getSource(), _function);
    final Procedure0 _function_1 = () -> {
      MultirotorSimulationControlCapacity _$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_MULTIROTORSIMULATIONCONTROLCAPACITY$CALLER = this.$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_MULTIROTORSIMULATIONCONTROLCAPACITY$CALLER();
      _$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_MULTIROTORSIMULATIONCONTROLCAPACITY$CALLER.moveByVelocity(body, occurrence.vx, occurrence.vy, occurrence.vz, occurrence.duration);
    };
    this.influenceReactionStrategy.influenceReceived(occurrence.getSource(), _function_1);
    Logging _$CAPACITY_USE$IO_SARL_API_CORE_LOGGING$CALLER_1 = this.$CAPACITY_USE$IO_SARL_API_CORE_LOGGING$CALLER();
    _$CAPACITY_USE$IO_SARL_API_CORE_LOGGING$CALLER_1.debug("MoveByVelocity (end)");
  }

  /**
   * Retrieve the perceptions for a single agent
   */
  private void retrieveAgentPerceptions(final Address address, final String name) {
    MultirotorSimulationPerceptionCapacity _$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_MULTIROTORSIMULATIONPERCEPTIONCAPACITY$CALLER = this.$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_MULTIROTORSIMULATIONPERCEPTIONCAPACITY$CALLER();
    final MultirotorState state = _$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_MULTIROTORSIMULATIONPERCEPTIONCAPACITY$CALLER.getMultirotorState(name);
    SimulationPerceptionCapacity _$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_SIMULATIONPERCEPTIONCAPACITY$CALLER = this.$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_SIMULATIONPERCEPTIONCAPACITY$CALLER();
    final Pose pose = _$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_SIMULATIONPERCEPTIONCAPACITY$CALLER.simGetObjectPose(name);
    SimulationPerceptionCapacity _$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_SIMULATIONPERCEPTIONCAPACITY$CALLER_1 = this.$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_SIMULATIONPERCEPTIONCAPACITY$CALLER();
    final KinematicsState kinematics = _$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_SIMULATIONPERCEPTIONCAPACITY$CALLER_1.simGetGroundTruthKinematics(name);
    final Procedure0 _function = () -> {
      DefaultContextInteractions _$CAPACITY_USE$IO_SARL_API_CORE_DEFAULTCONTEXTINTERACTIONS$CALLER = this.$CAPACITY_USE$IO_SARL_API_CORE_DEFAULTCONTEXTINTERACTIONS$CALLER();
      MultirotorStatePerception _multirotorStatePerception = new MultirotorStatePerception(state);
      class $SerializableClosureProxy implements Scope<Address> {
        
        private final Address address;
        
        public $SerializableClosureProxy(final Address address) {
          this.address = address;
        }
        
        @Override
        public boolean matches(final Address it) {
          return Objects.equal(it, address);
        }
      }
      final Scope<Address> _function_1 = new Scope<Address>() {
        @Override
        public boolean matches(final Address it) {
          return Objects.equal(it, address);
        }
        private Object writeReplace() throws ObjectStreamException {
          return new SerializableProxy($SerializableClosureProxy.class, address);
        }
      };
      _$CAPACITY_USE$IO_SARL_API_CORE_DEFAULTCONTEXTINTERACTIONS$CALLER.emit(_multirotorStatePerception, _function_1);
      DefaultContextInteractions _$CAPACITY_USE$IO_SARL_API_CORE_DEFAULTCONTEXTINTERACTIONS$CALLER_1 = this.$CAPACITY_USE$IO_SARL_API_CORE_DEFAULTCONTEXTINTERACTIONS$CALLER();
      SimPosePerception _simPosePerception = new SimPosePerception(pose);
      class $SerializableClosureProxy_1 implements Scope<Address> {
        
        private final Address address;
        
        public $SerializableClosureProxy_1(final Address address) {
          this.address = address;
        }
        
        @Override
        public boolean matches(final Address it) {
          return Objects.equal(it, address);
        }
      }
      final Scope<Address> _function_2 = new Scope<Address>() {
        @Override
        public boolean matches(final Address it) {
          return Objects.equal(it, address);
        }
        private Object writeReplace() throws ObjectStreamException {
          return new SerializableProxy($SerializableClosureProxy_1.class, address);
        }
      };
      _$CAPACITY_USE$IO_SARL_API_CORE_DEFAULTCONTEXTINTERACTIONS$CALLER_1.emit(_simPosePerception, _function_2);
      DefaultContextInteractions _$CAPACITY_USE$IO_SARL_API_CORE_DEFAULTCONTEXTINTERACTIONS$CALLER_2 = this.$CAPACITY_USE$IO_SARL_API_CORE_DEFAULTCONTEXTINTERACTIONS$CALLER();
      SimGroundTruthKinematicsPerception _simGroundTruthKinematicsPerception = new SimGroundTruthKinematicsPerception(kinematics);
      class $SerializableClosureProxy_2 implements Scope<Address> {
        
        private final Address address;
        
        public $SerializableClosureProxy_2(final Address address) {
          this.address = address;
        }
        
        @Override
        public boolean matches(final Address it) {
          return Objects.equal(it, address);
        }
      }
      final Scope<Address> _function_3 = new Scope<Address>() {
        @Override
        public boolean matches(final Address it) {
          return Objects.equal(it, address);
        }
        private Object writeReplace() throws ObjectStreamException {
          return new SerializableProxy($SerializableClosureProxy_2.class, address);
        }
      };
      _$CAPACITY_USE$IO_SARL_API_CORE_DEFAULTCONTEXTINTERACTIONS$CALLER_2.emit(_simGroundTruthKinematicsPerception, _function_3);
    };
    this.influenceReactionStrategy.perceptionReceived(address, _function);
  }

  /**
   * Retrieve the perceptions for all agents
   */
  private void retrievePerceptions() {
    final BiConsumer<Address, String> _function = (Address address, String name) -> {
      this.retrieveAgentPerceptions(address, name);
    };
    this.affectationStrategy.affectedBodies().forEach(_function);
  }

  private void onAffectation(final Address address, final String name) {
    Logging _$CAPACITY_USE$IO_SARL_API_CORE_LOGGING$CALLER = this.$CAPACITY_USE$IO_SARL_API_CORE_LOGGING$CALLER();
    UUID _uUID = address.getID();
    _$CAPACITY_USE$IO_SARL_API_CORE_LOGGING$CALLER.info(((("Received affectation: " + _uUID) + " - ") + name));
    MultirotorSimulationControlCapacity _$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_MULTIROTORSIMULATIONCONTROLCAPACITY$CALLER = this.$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_MULTIROTORSIMULATIONCONTROLCAPACITY$CALLER();
    _$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_MULTIROTORSIMULATIONCONTROLCAPACITY$CALLER.enableControl(name);
    this.retrieveAgentPerceptions(address, name);
  }

  @Extension
  @ImportedCapacityFeature(Logging.class)
  @SyntheticMember
  private transient AtomicSkillReference $CAPACITY_USE$IO_SARL_API_CORE_LOGGING;

  @SyntheticMember
  @Pure
  private Logging $CAPACITY_USE$IO_SARL_API_CORE_LOGGING$CALLER() {
    if (this.$CAPACITY_USE$IO_SARL_API_CORE_LOGGING == null || this.$CAPACITY_USE$IO_SARL_API_CORE_LOGGING.get() == null) {
      this.$CAPACITY_USE$IO_SARL_API_CORE_LOGGING = $getSkill(Logging.class);
    }
    return $castSkill(Logging.class, this.$CAPACITY_USE$IO_SARL_API_CORE_LOGGING);
  }

  @Extension
  @ImportedCapacityFeature(DefaultContextInteractions.class)
  @SyntheticMember
  private transient AtomicSkillReference $CAPACITY_USE$IO_SARL_API_CORE_DEFAULTCONTEXTINTERACTIONS;

  @SyntheticMember
  @Pure
  private DefaultContextInteractions $CAPACITY_USE$IO_SARL_API_CORE_DEFAULTCONTEXTINTERACTIONS$CALLER() {
    if (this.$CAPACITY_USE$IO_SARL_API_CORE_DEFAULTCONTEXTINTERACTIONS == null || this.$CAPACITY_USE$IO_SARL_API_CORE_DEFAULTCONTEXTINTERACTIONS.get() == null) {
      this.$CAPACITY_USE$IO_SARL_API_CORE_DEFAULTCONTEXTINTERACTIONS = $getSkill(DefaultContextInteractions.class);
    }
    return $castSkill(DefaultContextInteractions.class, this.$CAPACITY_USE$IO_SARL_API_CORE_DEFAULTCONTEXTINTERACTIONS);
  }

  @Extension
  @ImportedCapacityFeature(Schedules.class)
  @SyntheticMember
  private transient AtomicSkillReference $CAPACITY_USE$IO_SARL_API_CORE_SCHEDULES;

  @SyntheticMember
  @Pure
  private Schedules $CAPACITY_USE$IO_SARL_API_CORE_SCHEDULES$CALLER() {
    if (this.$CAPACITY_USE$IO_SARL_API_CORE_SCHEDULES == null || this.$CAPACITY_USE$IO_SARL_API_CORE_SCHEDULES.get() == null) {
      this.$CAPACITY_USE$IO_SARL_API_CORE_SCHEDULES = $getSkill(Schedules.class);
    }
    return $castSkill(Schedules.class, this.$CAPACITY_USE$IO_SARL_API_CORE_SCHEDULES);
  }

  @Extension
  @ImportedCapacityFeature(SimulationControlCapacity.class)
  @SyntheticMember
  private transient AtomicSkillReference $CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_SIMULATIONCONTROLCAPACITY;

  @SyntheticMember
  @Pure
  private SimulationControlCapacity $CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_SIMULATIONCONTROLCAPACITY$CALLER() {
    if (this.$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_SIMULATIONCONTROLCAPACITY == null || this.$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_SIMULATIONCONTROLCAPACITY.get() == null) {
      this.$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_SIMULATIONCONTROLCAPACITY = $getSkill(SimulationControlCapacity.class);
    }
    return $castSkill(SimulationControlCapacity.class, this.$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_SIMULATIONCONTROLCAPACITY);
  }

  @Extension
  @ImportedCapacityFeature(MultirotorSimulationControlCapacity.class)
  @SyntheticMember
  private transient AtomicSkillReference $CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_MULTIROTORSIMULATIONCONTROLCAPACITY;

  @SyntheticMember
  @Pure
  private MultirotorSimulationControlCapacity $CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_MULTIROTORSIMULATIONCONTROLCAPACITY$CALLER() {
    if (this.$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_MULTIROTORSIMULATIONCONTROLCAPACITY == null || this.$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_MULTIROTORSIMULATIONCONTROLCAPACITY.get() == null) {
      this.$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_MULTIROTORSIMULATIONCONTROLCAPACITY = $getSkill(MultirotorSimulationControlCapacity.class);
    }
    return $castSkill(MultirotorSimulationControlCapacity.class, this.$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_MULTIROTORSIMULATIONCONTROLCAPACITY);
  }

  @Extension
  @ImportedCapacityFeature(SimulationPerceptionCapacity.class)
  @SyntheticMember
  private transient AtomicSkillReference $CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_SIMULATIONPERCEPTIONCAPACITY;

  @SyntheticMember
  @Pure
  private SimulationPerceptionCapacity $CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_SIMULATIONPERCEPTIONCAPACITY$CALLER() {
    if (this.$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_SIMULATIONPERCEPTIONCAPACITY == null || this.$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_SIMULATIONPERCEPTIONCAPACITY.get() == null) {
      this.$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_SIMULATIONPERCEPTIONCAPACITY = $getSkill(SimulationPerceptionCapacity.class);
    }
    return $castSkill(SimulationPerceptionCapacity.class, this.$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_SIMULATIONPERCEPTIONCAPACITY);
  }

  @Extension
  @ImportedCapacityFeature(MultirotorSimulationPerceptionCapacity.class)
  @SyntheticMember
  private transient AtomicSkillReference $CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_MULTIROTORSIMULATIONPERCEPTIONCAPACITY;

  @SyntheticMember
  @Pure
  private MultirotorSimulationPerceptionCapacity $CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_MULTIROTORSIMULATIONPERCEPTIONCAPACITY$CALLER() {
    if (this.$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_MULTIROTORSIMULATIONPERCEPTIONCAPACITY == null || this.$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_MULTIROTORSIMULATIONPERCEPTIONCAPACITY.get() == null) {
      this.$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_MULTIROTORSIMULATIONPERCEPTIONCAPACITY = $getSkill(MultirotorSimulationPerceptionCapacity.class);
    }
    return $castSkill(MultirotorSimulationPerceptionCapacity.class, this.$CAPACITY_USE$IO_SARL_AIRSIM_SIMULATION_CAPACITIES_MULTIROTORSIMULATIONPERCEPTIONCAPACITY);
  }

  @SyntheticMember
  @PerceptGuardEvaluator
  private void $guardEvaluator$Initialize(final Initialize occurrence, final Collection<Runnable> ___SARLlocal_runnableCollection) {
    assert occurrence != null;
    assert ___SARLlocal_runnableCollection != null;
    ___SARLlocal_runnableCollection.add(() -> $behaviorUnit$Initialize$0(occurrence));
  }

  /**
   * When a drone emits the take-off instruction, transfers it to AirSim
   */
  @SyntheticMember
  @PerceptGuardEvaluator
  private void $guardEvaluator$Takeoff(final Takeoff occurrence, final Collection<Runnable> ___SARLlocal_runnableCollection) {
    assert occurrence != null;
    assert ___SARLlocal_runnableCollection != null;
    ___SARLlocal_runnableCollection.add(() -> $behaviorUnit$Takeoff$1(occurrence));
  }

  /**
   * When a drone emits the move-by-velocity instruction, transfers it to AirSim
   */
  @SyntheticMember
  @PerceptGuardEvaluator
  private void $guardEvaluator$MoveByVelocity(final MoveByVelocity occurrence, final Collection<Runnable> ___SARLlocal_runnableCollection) {
    assert occurrence != null;
    assert ___SARLlocal_runnableCollection != null;
    ___SARLlocal_runnableCollection.add(() -> $behaviorUnit$MoveByVelocity$2(occurrence));
  }

  @SyntheticMember
  @Override
  public void $getSupportedEvents(final Set<Class<? extends Event>> toBeFilled) {
    super.$getSupportedEvents(toBeFilled);
    toBeFilled.add(MoveByVelocity.class);
    toBeFilled.add(Takeoff.class);
    toBeFilled.add(Initialize.class);
  }

  @SyntheticMember
  @Override
  public boolean $isSupportedEvent(final Class<? extends Event> event) {
    if (MoveByVelocity.class.isAssignableFrom(event)) {
      return true;
    }
    if (Takeoff.class.isAssignableFrom(event)) {
      return true;
    }
    if (Initialize.class.isAssignableFrom(event)) {
      return true;
    }
    return false;
  }

  @SyntheticMember
  @Override
  public void $evaluateBehaviorGuards(final Object event, final Collection<Runnable> callbacks) {
    super.$evaluateBehaviorGuards(event, callbacks);
    if (event instanceof MoveByVelocity) {
      final MoveByVelocity occurrence = (MoveByVelocity) event;
      $guardEvaluator$MoveByVelocity(occurrence, callbacks);
    }
    if (event instanceof Takeoff) {
      final Takeoff occurrence = (Takeoff) event;
      $guardEvaluator$Takeoff(occurrence, callbacks);
    }
    if (event instanceof Initialize) {
      final Initialize occurrence = (Initialize) event;
      $guardEvaluator$Initialize(occurrence, callbacks);
    }
  }

  @Override
  @Pure
  @SyntheticMember
  public boolean equals(final Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    SimulationControllerAgent other = (SimulationControllerAgent) obj;
    if (Float.floatToIntBits(other.simulationStepMs) != Float.floatToIntBits(this.simulationStepMs))
      return false;
    return super.equals(obj);
  }

  @Override
  @Pure
  @SyntheticMember
  public int hashCode() {
    int result = super.hashCode();
    final int prime = 31;
    result = prime * result + Float.hashCode(this.simulationStepMs);
    return result;
  }

  @SyntheticMember
  public SimulationControllerAgent(final UUID arg0, final UUID arg1) {
    super(arg0, arg1);
  }

  @SyntheticMember
  @Inject
  public SimulationControllerAgent(final UUID arg0, final UUID arg1, final DynamicSkillProvider arg2) {
    super(arg0, arg1, arg2);
  }
}
