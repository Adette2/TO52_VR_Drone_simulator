package io.sarl.airsim.simulation.skills.mock;

import io.sarl.airsim.simulation.capacities.MultirotorSimulationControlCapacity;
import io.sarl.lang.core.Agent;
import io.sarl.lang.core.Skill;
import io.sarl.lang.core.annotation.SarlElementType;
import io.sarl.lang.core.annotation.SarlSpecification;
import io.sarl.lang.core.annotation.SyntheticMember;

/**
 * Mock for the multirotor control implementing the corresponding capacity.
 * Does not have any behavior.
 * @author Alexandre Lombard
 */
@SarlSpecification("0.13")
@SarlElementType(22)
@SuppressWarnings("all")
public class MockMultirotorControl extends Skill implements MultirotorSimulationControlCapacity {
  @Override
  public void takeOff(final String vehicleName) {
  }

  @Override
  public void land(final String vehicleName) {
  }

  @Override
  public void rotateByYawRate(final String vehicleName, final Float yawRate, final Float duration) {
  }

  @Override
  public void rotateToYaw(final String vehicleName, final Float yaw) {
  }

  @Override
  public void goHome(final String vehicleName) {
  }

  @Override
  public void moveByVelocity(final String vehicleName, final Float vx, final Float vy, final Float vz, final Float duration) {
  }

  @Override
  public void enableControl(final String vehicleName) {
  }

  @Override
  public void moveToPosition(final String vehicleName, final Float x, final Float y, final Float z, final Float velocity) {
  }

  @SyntheticMember
  public MockMultirotorControl() {
    super();
  }

  @SyntheticMember
  public MockMultirotorControl(final Agent arg0) {
    super(arg0);
  }
}
