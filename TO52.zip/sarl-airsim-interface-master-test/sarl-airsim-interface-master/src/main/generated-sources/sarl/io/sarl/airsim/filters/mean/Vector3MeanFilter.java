package io.sarl.airsim.filters.mean;

import io.sarl.airsim.math.Vector3;
import io.sarl.lang.core.annotation.DefaultValue;
import io.sarl.lang.core.annotation.DefaultValueSource;
import io.sarl.lang.core.annotation.DefaultValueUse;
import io.sarl.lang.core.annotation.SarlElementType;
import io.sarl.lang.core.annotation.SarlSourceCode;
import io.sarl.lang.core.annotation.SarlSpecification;
import io.sarl.lang.core.annotation.SyntheticMember;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.Functions.Function2;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.ListExtensions;
import org.eclipse.xtext.xbase.lib.Pure;

/**
 * Mean filter for Vector3 objects
 * @author Alexandre
 */
@SarlSpecification("0.13")
@SarlElementType(10)
@SuppressWarnings("all")
public class Vector3MeanFilter extends AbstractMeanFilter<Vector3> {
  /**
   * Builds the mean filter with the given default value
   * @param size the size of the kernel
   * @param defaultValue the default value when building the kernel
   */
  @DefaultValueSource
  public Vector3MeanFilter(final Integer size, @DefaultValue("io.sarl.airsim.filters.mean.Vector3MeanFilter#NEW_0") final Vector3 defaultValue) {
    super(size, defaultValue);
  }

  public Vector3 filter(final Vector3 v) {
    this.addValue(v);
    final Function1<Vector3, Vector3> _function = (Vector3 it) -> {
      int _size = this.values.size();
      return it.operator_multiply(Float.valueOf((1.0f / _size)));
    };
    final Function2<Vector3, Vector3, Vector3> _function_1 = (Vector3 p1, Vector3 p2) -> {
      return p1.operator_plus(p2);
    };
    return IterableExtensions.<Vector3>reduce(ListExtensions.<Vector3, Vector3>map(this.values, _function), _function_1);
  }

  /**
   * Default value for the parameter defaultValue
   */
  @Pure
  @SyntheticMember
  @SarlSourceCode("new Vector3()")
  private static Vector3 $DEFAULT_VALUE$NEW_0() {
    Vector3 _vector3 = new Vector3();
    return _vector3;
  }

  /**
   * Builds the mean filter with the given default value
   * @optionalparam size the size of the kernel
   * @optionalparam defaultValue the default value when building the kernel
   */
  @DefaultValueUse("java.lang.Integer,io.sarl.airsim.math.Vector3")
  @SyntheticMember
  public Vector3MeanFilter(final Integer size) {
    this(size, $DEFAULT_VALUE$NEW_0());
  }
}
