package io.sarl.airsim.simulation.scheduling;

import io.sarl.lang.core.annotation.SarlElementType;
import io.sarl.lang.core.annotation.SarlSpecification;

/**
 * Interface for a scheduling strategy, it only contains a method which will be
 * the loop of the simulation SARL side: i.e. getting the perceptions, running the simulation side.
 * @author Alexandre Lombard
 */
@FunctionalInterface
@SarlSpecification("0.13")
@SarlElementType(11)
@SuppressWarnings("all")
public interface SimulationStrategy {
  /**
   * Run a simulation loop (SARL side)
   */
  void loop();
}
