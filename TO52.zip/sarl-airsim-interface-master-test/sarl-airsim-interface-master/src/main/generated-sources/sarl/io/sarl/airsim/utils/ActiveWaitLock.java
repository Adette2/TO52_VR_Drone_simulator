package io.sarl.airsim.utils;

import io.sarl.lang.core.annotation.SarlElementType;
import io.sarl.lang.core.annotation.SarlSpecification;
import io.sarl.lang.core.annotation.SyntheticMember;
import org.eclipse.xtext.xbase.lib.Pure;

/**
 * A kind of lock or synchronized flag
 * @author Alexandre Lombard
 */
@SarlSpecification("0.13")
@SarlElementType(10)
@SuppressWarnings("all")
public class ActiveWaitLock {
  private volatile boolean locked = false;

  /**
   * Sets the lock state to true
   */
  public synchronized void lock() {
    this.locked = true;
  }

  /**
   * Sets the lock state to false
   */
  public synchronized void unlock() {
    this.locked = false;
  }

  /**
   * Returns the current lock state
   */
  @Pure
  public synchronized boolean isLocked() {
    return this.locked;
  }

  @Override
  @Pure
  @SyntheticMember
  public boolean equals(final Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    ActiveWaitLock other = (ActiveWaitLock) obj;
    if (other.locked != this.locked)
      return false;
    return super.equals(obj);
  }

  @Override
  @Pure
  @SyntheticMember
  public int hashCode() {
    int result = super.hashCode();
    final int prime = 31;
    result = prime * result + Boolean.hashCode(this.locked);
    return result;
  }

  @SyntheticMember
  public ActiveWaitLock() {
    super();
  }
}
