package io.sarl.airsim.simulation.scheduling;

import io.sarl.lang.core.annotation.SarlElementType;
import io.sarl.lang.core.annotation.SarlSpecification;
import io.sarl.lang.core.annotation.SyntheticMember;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.Functions.Function0;
import org.eclipse.xtext.xbase.lib.ObjectExtensions;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure0;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;
import org.eclipse.xtext.xbase.lib.Pure;

/**
 * Fixed step scheduling strategy. The simulation is paused, then perceptions are retrieved, then
 * simulation continues for a given amount of time, if and only if, a condition is met, etc. for each loop.
 * @author Alexandre Lombard
 */
@SarlSpecification("0.13")
@SarlElementType(10)
@SuppressWarnings("all")
public class FixedStepBlockingSimulationStrategy implements SimulationStrategy {
  @SarlSpecification("0.13")
  @SarlElementType(10)
  public static class FixedStepBlockingSimulationStrategyBuilder {
    public Procedure0 retrievePerceptionsBy;

    public Function0<? extends Boolean> canContinueIf;

    public Procedure0 continueSimulationBy;

    @Pure
    public FixedStepBlockingSimulationStrategy build() {
      return new FixedStepBlockingSimulationStrategy(
        this.retrievePerceptionsBy, this.canContinueIf, this.continueSimulationBy);
    }

    @Override
    @Pure
    @SyntheticMember
    public boolean equals(final Object obj) {
      return super.equals(obj);
    }

    @Override
    @Pure
    @SyntheticMember
    public int hashCode() {
      int result = super.hashCode();
      return result;
    }

    @SyntheticMember
    public FixedStepBlockingSimulationStrategyBuilder() {
      super();
    }
  }

  private final Procedure0 retrievePerceptions;

  private final Procedure0 continueSimulation;

  private final Function0<? extends Boolean> canContinue;

  public FixedStepBlockingSimulationStrategy(final Procedure0 retrievePerceptions, final Function0<? extends Boolean> canContinue, final Procedure0 continueSimulation) {
    this.retrievePerceptions = retrievePerceptions;
    this.continueSimulation = continueSimulation;
    this.canContinue = canContinue;
  }

  @SuppressWarnings("discouraged_reference")
  public void loop() {
    try {
      this.retrievePerceptions.apply();
      while ((((this.canContinue.apply()) == null ? false : (this.canContinue.apply()).booleanValue()) == false)) {
        Thread.sleep(10);
      }
      this.continueSimulation.apply();
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }

  /**
   * Builds a FixedStepBlockingSimulationStrategy
   */
  @Pure
  public static FixedStepBlockingSimulationStrategy fixedStepBlockingSimulationStrategy(final Procedure1<FixedStepBlockingSimulationStrategy.FixedStepBlockingSimulationStrategyBuilder> init) {
    FixedStepBlockingSimulationStrategy.FixedStepBlockingSimulationStrategyBuilder _fixedStepBlockingSimulationStrategyBuilder = new FixedStepBlockingSimulationStrategy.FixedStepBlockingSimulationStrategyBuilder();
    final FixedStepBlockingSimulationStrategy.FixedStepBlockingSimulationStrategyBuilder strategyBuilder = ObjectExtensions.<FixedStepBlockingSimulationStrategy.FixedStepBlockingSimulationStrategyBuilder>operator_doubleArrow(_fixedStepBlockingSimulationStrategyBuilder, init);
    return strategyBuilder.build();
  }

  @Override
  @Pure
  @SyntheticMember
  public boolean equals(final Object obj) {
    return super.equals(obj);
  }

  @Override
  @Pure
  @SyntheticMember
  public int hashCode() {
    int result = super.hashCode();
    return result;
  }
}
