package io.sarl.airsim.simulation.skills.mock;

import fr.utbm.airsim.api.CollisionInfo;
import fr.utbm.airsim.api.KinematicsState;
import fr.utbm.airsim.api.Pose;
import io.sarl.airsim.simulation.capacities.SimulationPerceptionCapacity;
import io.sarl.lang.core.Agent;
import io.sarl.lang.core.Skill;
import io.sarl.lang.core.annotation.SarlElementType;
import io.sarl.lang.core.annotation.SarlSpecification;
import io.sarl.lang.core.annotation.SyntheticMember;

/**
 * Mock for the multirotor simulation perception implementing the corresponding capacity.
 * The behavior is to return empty and constant perceptions.
 * @author Alexandre Lombard
 */
@SarlSpecification("0.13")
@SarlElementType(22)
@SuppressWarnings("all")
public class MockSimulationPerception extends Skill implements SimulationPerceptionCapacity {
  public Pose simGetObjectPose(final String objectName) {
    return new Pose();
  }

  public CollisionInfo simGetCollisionInfo(final String vehicleName) {
    return new CollisionInfo();
  }

  public KinematicsState simGetGroundTruthKinematics(final String vehicleName) {
    return new KinematicsState();
  }

  @SyntheticMember
  public MockSimulationPerception() {
    super();
  }

  @SyntheticMember
  public MockSimulationPerception(final Agent arg0) {
    super(arg0);
  }
}
