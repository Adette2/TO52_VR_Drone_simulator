package io.sarl.airsim.behaviors.tests;

import io.sarl.airsim.influences.MoveByVelocity;
import io.sarl.airsim.influences.Takeoff;
import io.sarl.airsim.math.Vector3;
import io.sarl.airsim.perceptions.LidarDataPerception;
import io.sarl.airsim.simulation.events.SimulationInitialized;
import io.sarl.api.core.DefaultContextInteractions;
import io.sarl.lang.core.Agent;
import io.sarl.lang.core.AtomicSkillReference;
import io.sarl.lang.core.Behavior;
import io.sarl.lang.core.Event;
import io.sarl.lang.core.annotation.ImportedCapacityFeature;
import io.sarl.lang.core.annotation.PerceptGuardEvaluator;
import io.sarl.lang.core.annotation.SarlElementType;
import io.sarl.lang.core.annotation.SarlSpecification;
import io.sarl.lang.core.annotation.SyntheticMember;
import java.util.Collection;
import java.util.Set;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.Extension;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.Pure;

/**
 * Test behavior emitting a take off instruction when the simulation is initialized, then moving forward
 * or stopping according to the lidar
 * @author Alexandre Lombard
 */
@SarlSpecification("0.13")
@SarlElementType(21)
@SuppressWarnings("all")
public class TakeoffBehavior extends Behavior {
  private void $behaviorUnit$SimulationInitialized$0(final SimulationInitialized occurrence) {
    DefaultContextInteractions _$CAPACITY_USE$IO_SARL_API_CORE_DEFAULTCONTEXTINTERACTIONS$CALLER = this.$CAPACITY_USE$IO_SARL_API_CORE_DEFAULTCONTEXTINTERACTIONS$CALLER();
    Takeoff _takeoff = new Takeoff();
    _$CAPACITY_USE$IO_SARL_API_CORE_DEFAULTCONTEXTINTERACTIONS$CALLER.emit(_takeoff);
  }

  private void $behaviorUnit$LidarDataPerception$1(final LidarDataPerception occurrence) {
    DefaultContextInteractions _$CAPACITY_USE$IO_SARL_API_CORE_DEFAULTCONTEXTINTERACTIONS$CALLER = this.$CAPACITY_USE$IO_SARL_API_CORE_DEFAULTCONTEXTINTERACTIONS$CALLER();
    Vector3 _vector3 = new Vector3(Float.valueOf(0.0f), Float.valueOf(0.0f), Float.valueOf(0.0f));
    MoveByVelocity _moveByVelocity = new MoveByVelocity(_vector3, Float.valueOf(0.1f));
    _$CAPACITY_USE$IO_SARL_API_CORE_DEFAULTCONTEXTINTERACTIONS$CALLER.emit(_moveByVelocity);
  }

  @SyntheticMember
  @Pure
  private boolean $behaviorUnitGuard$LidarDataPerception$1(final LidarDataPerception it, final LidarDataPerception occurrence) {
    Float _minDistance = this.minDistance(occurrence.lidarData.getPointCloud());
    return (_minDistance.floatValue() < 10.0f);
  }

  private void $behaviorUnit$LidarDataPerception$2(final LidarDataPerception occurrence) {
    DefaultContextInteractions _$CAPACITY_USE$IO_SARL_API_CORE_DEFAULTCONTEXTINTERACTIONS$CALLER = this.$CAPACITY_USE$IO_SARL_API_CORE_DEFAULTCONTEXTINTERACTIONS$CALLER();
    Vector3 _vector3 = new Vector3(Float.valueOf(10.0f), Float.valueOf(0.0f), Float.valueOf(0.0f));
    MoveByVelocity _moveByVelocity = new MoveByVelocity(_vector3, Float.valueOf(0.1f));
    _$CAPACITY_USE$IO_SARL_API_CORE_DEFAULTCONTEXTINTERACTIONS$CALLER.emit(_moveByVelocity);
  }

  @SyntheticMember
  @Pure
  private boolean $behaviorUnitGuard$LidarDataPerception$2(final LidarDataPerception it, final LidarDataPerception occurrence) {
    Float _minDistance = this.minDistance(occurrence.lidarData.getPointCloud());
    return (_minDistance.floatValue() >= 10.0f);
  }

  @Pure
  public Float minDistance(final float[] arr) {
    return IterableExtensions.<Float>min(((Iterable<Float>)Conversions.doWrapArray(arr)));
  }

  @Extension
  @ImportedCapacityFeature(DefaultContextInteractions.class)
  @SyntheticMember
  private transient AtomicSkillReference $CAPACITY_USE$IO_SARL_API_CORE_DEFAULTCONTEXTINTERACTIONS;

  @SyntheticMember
  @Pure
  private DefaultContextInteractions $CAPACITY_USE$IO_SARL_API_CORE_DEFAULTCONTEXTINTERACTIONS$CALLER() {
    if (this.$CAPACITY_USE$IO_SARL_API_CORE_DEFAULTCONTEXTINTERACTIONS == null || this.$CAPACITY_USE$IO_SARL_API_CORE_DEFAULTCONTEXTINTERACTIONS.get() == null) {
      this.$CAPACITY_USE$IO_SARL_API_CORE_DEFAULTCONTEXTINTERACTIONS = $getSkill(DefaultContextInteractions.class);
    }
    return $castSkill(DefaultContextInteractions.class, this.$CAPACITY_USE$IO_SARL_API_CORE_DEFAULTCONTEXTINTERACTIONS);
  }

  @SyntheticMember
  @PerceptGuardEvaluator
  private void $guardEvaluator$SimulationInitialized(final SimulationInitialized occurrence, final Collection<Runnable> ___SARLlocal_runnableCollection) {
    assert occurrence != null;
    assert ___SARLlocal_runnableCollection != null;
    ___SARLlocal_runnableCollection.add(() -> $behaviorUnit$SimulationInitialized$0(occurrence));
  }

  @SyntheticMember
  @PerceptGuardEvaluator
  private void $guardEvaluator$LidarDataPerception(final LidarDataPerception occurrence, final Collection<Runnable> ___SARLlocal_runnableCollection) {
    assert occurrence != null;
    assert ___SARLlocal_runnableCollection != null;
    if ($behaviorUnitGuard$LidarDataPerception$1(occurrence, occurrence)) {
      ___SARLlocal_runnableCollection.add(() -> $behaviorUnit$LidarDataPerception$1(occurrence));
    }
    if ($behaviorUnitGuard$LidarDataPerception$2(occurrence, occurrence)) {
      ___SARLlocal_runnableCollection.add(() -> $behaviorUnit$LidarDataPerception$2(occurrence));
    }
  }

  @SyntheticMember
  @Override
  public void $getSupportedEvents(final Set<Class<? extends Event>> toBeFilled) {
    super.$getSupportedEvents(toBeFilled);
    toBeFilled.add(LidarDataPerception.class);
    toBeFilled.add(SimulationInitialized.class);
  }

  @SyntheticMember
  @Override
  public boolean $isSupportedEvent(final Class<? extends Event> event) {
    if (LidarDataPerception.class.isAssignableFrom(event)) {
      return true;
    }
    if (SimulationInitialized.class.isAssignableFrom(event)) {
      return true;
    }
    return false;
  }

  @SyntheticMember
  @Override
  public void $evaluateBehaviorGuards(final Object event, final Collection<Runnable> callbacks) {
    super.$evaluateBehaviorGuards(event, callbacks);
    if (event instanceof LidarDataPerception) {
      final LidarDataPerception occurrence = (LidarDataPerception) event;
      $guardEvaluator$LidarDataPerception(occurrence, callbacks);
    }
    if (event instanceof SimulationInitialized) {
      final SimulationInitialized occurrence = (SimulationInitialized) event;
      $guardEvaluator$SimulationInitialized(occurrence, callbacks);
    }
  }

  @SyntheticMember
  public TakeoffBehavior(final Agent arg0) {
    super(arg0);
  }
}
