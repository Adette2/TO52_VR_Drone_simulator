package io.sarl.airsim.simulation.influence;

import io.sarl.lang.core.Address;
import io.sarl.lang.core.annotation.SarlElementType;
import io.sarl.lang.core.annotation.SarlSpecification;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure0;

/**
 * Represents an abstract simulation scheduling strategy.
 * The role of a simulation strategy is to retrieve and propagate perceptions, collect corresponding influences and apply them
 * @author Alexandre Lombard
 */
@SarlSpecification("0.13")
@SarlElementType(11)
@SuppressWarnings("all")
public interface InfluenceReactionStrategy {
  /**
   * This must be called when a perception is received, the perception management parameter specifies
   * how the perception should be propagated.
   */
  void perceptionReceived(final Address destination, final Procedure0 propagate);

  /**
   * This must be called when an influence is received, the influence management parameter specifies
   * how the influence should be propagated.
   */
  void influenceReceived(final Address source, final Procedure0 propagate);
}
