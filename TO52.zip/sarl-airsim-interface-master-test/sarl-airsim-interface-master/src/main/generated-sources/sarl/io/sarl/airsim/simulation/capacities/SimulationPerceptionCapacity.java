package io.sarl.airsim.simulation.capacities;

import fr.utbm.airsim.api.CollisionInfo;
import fr.utbm.airsim.api.KinematicsState;
import fr.utbm.airsim.api.Pose;
import io.sarl.lang.core.AgentTrait;
import io.sarl.lang.core.Capacity;
import io.sarl.lang.core.annotation.SarlElementType;
import io.sarl.lang.core.annotation.SarlSpecification;

/**
 * The capacity to perceive the simulation state (not through sensors, but like an omniscient god)
 * @author Alexandre Lombard
 */
@SarlSpecification("0.13")
@SarlElementType(20)
@SuppressWarnings("all")
public interface SimulationPerceptionCapacity extends Capacity {
  /**
   * Gets the position of the given object
   * @param objectName the name of the object
   * @return the object's pose
   */
  Pose simGetObjectPose(final String objectName);

  /**
   * Gets the collision info for the given vehicle
   * @param vehicleName the name of the vehicle
   * @return the collision info
   */
  CollisionInfo simGetCollisionInfo(final String vehicleName);

  /**
   * Gets the ground truth kinematics state for the given vehicle
   * @param vehicleName the name of the vehicle
   * @return the kinematics state
   */
  KinematicsState simGetGroundTruthKinematics(final String vehicleName);

  /**
   * @ExcludeFromApidoc
   */
  class ContextAwareCapacityWrapper<C extends SimulationPerceptionCapacity> extends Capacity.ContextAwareCapacityWrapper<C> implements SimulationPerceptionCapacity {
    public ContextAwareCapacityWrapper(final C capacity, final AgentTrait caller) {
      super(capacity, caller);
    }

    public Pose simGetObjectPose(final String objectName) {
      try {
        ensureCallerInLocalThread();
        return this.capacity.simGetObjectPose(objectName);
      } finally {
        resetCallerInLocalThread();
      }
    }

    public CollisionInfo simGetCollisionInfo(final String vehicleName) {
      try {
        ensureCallerInLocalThread();
        return this.capacity.simGetCollisionInfo(vehicleName);
      } finally {
        resetCallerInLocalThread();
      }
    }

    public KinematicsState simGetGroundTruthKinematics(final String vehicleName) {
      try {
        ensureCallerInLocalThread();
        return this.capacity.simGetGroundTruthKinematics(vehicleName);
      } finally {
        resetCallerInLocalThread();
      }
    }
  }
}
