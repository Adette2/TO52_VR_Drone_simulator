package io.sarl.airsim.simulation.scheduling;

import io.sarl.lang.core.annotation.SarlElementType;
import io.sarl.lang.core.annotation.SarlSpecification;
import io.sarl.lang.core.annotation.SyntheticMember;
import org.eclipse.xtext.xbase.lib.ObjectExtensions;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure0;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;
import org.eclipse.xtext.xbase.lib.Pure;

/**
 * Fixed step scheduling strategy. The simulation is paused, then perceptions are retrieved, then
 * simulation continues for a given amount of time, etc. for each loop.
 * @author Alexandre Lombard
 */
@SarlSpecification("0.13")
@SarlElementType(10)
@SuppressWarnings("all")
public class FixedStepSimulationStrategy implements SimulationStrategy {
  @SarlSpecification("0.13")
  @SarlElementType(10)
  public static class FixedStepSimulationStrategyBuilder {
    public Procedure0 retrievePerceptionsBy;

    public Procedure0 continueSimulationBy;

    @Pure
    public FixedStepSimulationStrategy build() {
      return new FixedStepSimulationStrategy(this.retrievePerceptionsBy, this.continueSimulationBy);
    }

    @Override
    @Pure
    @SyntheticMember
    public boolean equals(final Object obj) {
      return super.equals(obj);
    }

    @Override
    @Pure
    @SyntheticMember
    public int hashCode() {
      int result = super.hashCode();
      return result;
    }

    @SyntheticMember
    public FixedStepSimulationStrategyBuilder() {
      super();
    }
  }

  private final Procedure0 retrievePerceptions;

  private final Procedure0 continueSimulation;

  public FixedStepSimulationStrategy(final Procedure0 retrievePerceptions, final Procedure0 continueSimulation) {
    this.retrievePerceptions = retrievePerceptions;
    this.continueSimulation = continueSimulation;
  }

  public void loop() {
    this.retrievePerceptions.apply();
    this.continueSimulation.apply();
  }

  /**
   * Builds a FiexStepSimulationStrategy
   */
  @Pure
  public static FixedStepSimulationStrategy fixedStepSimulationStrategy(final Procedure1<FixedStepSimulationStrategy.FixedStepSimulationStrategyBuilder> init) {
    FixedStepSimulationStrategy.FixedStepSimulationStrategyBuilder _fixedStepSimulationStrategyBuilder = new FixedStepSimulationStrategy.FixedStepSimulationStrategyBuilder();
    final FixedStepSimulationStrategy.FixedStepSimulationStrategyBuilder strategyBuilder = ObjectExtensions.<FixedStepSimulationStrategy.FixedStepSimulationStrategyBuilder>operator_doubleArrow(_fixedStepSimulationStrategyBuilder, init);
    return strategyBuilder.build();
  }

  @Override
  @Pure
  @SyntheticMember
  public boolean equals(final Object obj) {
    return super.equals(obj);
  }

  @Override
  @Pure
  @SyntheticMember
  public int hashCode() {
    int result = super.hashCode();
    return result;
  }
}
