package io.sarl.airsim.simulation.allocation;

import io.sarl.lang.core.Address;
import io.sarl.lang.core.annotation.DefaultValue;
import io.sarl.lang.core.annotation.DefaultValueSource;
import io.sarl.lang.core.annotation.DefaultValueUse;
import io.sarl.lang.core.annotation.SarlElementType;
import io.sarl.lang.core.annotation.SarlSourceCode;
import io.sarl.lang.core.annotation.SarlSpecification;
import io.sarl.lang.core.annotation.SyntheticMember;
import java.util.Map;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure2;
import org.eclipse.xtext.xbase.lib.Pure;

/**
 * Represents an allocation strategy making an association
 * between an agent and its body
 * @author Alexandre Lombard
 */
@SarlSpecification("0.13")
@SarlElementType(11)
@SuppressWarnings("all")
public interface AllocationStrategy {
  /**
   * Returns the number of affected bodies
   */
  Integer affectedBodiesCount();

  /**
   * Returns a view of the affected bodies
   */
  Map<Address, String> affectedBodies();

  /**
   * Gets the name of the body for the given agent address. May affect one if there is no current body.
   * @param address the address of the agent
   * @param onAffectation a callback when an agent is affected (by default it's empty)
   * @returns the name of the body if one exists, or <code>null</code> if there is no body for this address
   */
  @DefaultValueSource
  String affectOrGetBody(final Address address, @DefaultValue("io.sarl.airsim.simulation.allocation.AllocationStrategy#AFFECTORGETBODY_0") final Procedure2<Address, String> onAffectation);

  /**
   * Default value for the parameter onAffectation
   */
  @Pure
  @SyntheticMember
  @SarlSourceCode("[a,n|]")
  default Procedure2 $DEFAULT_VALUE$AFFECTORGETBODY_0() {
    final Procedure2<Object, Object> _function = (Object a, Object n) -> {
    };
    return _function;
  }

  /**
   * Gets the name of the body for the given agent address. May affect one if there is no current body.
   * @param address the address of the agent
   * @optionalparam onAffectation a callback when an agent is affected (by default it's empty)
   * @returns the name of the body if one exists, or <code>null</code> if there is no body for this address
   */
  @DefaultValueUse("io.sarl.lang.core.Address,(io.sarl.lang.core.Address, java.lang.String)=>void")
  @SyntheticMember
  default String affectOrGetBody(final Address address) {
    return affectOrGetBody(address, $DEFAULT_VALUE$AFFECTORGETBODY_0());
  }
}
