package io.sarl.airsim.filters;

import io.sarl.lang.core.annotation.SarlElementType;
import io.sarl.lang.core.annotation.SarlSpecification;

/**
 * Generic interface for filters
 * @author Alexandre Lombard
 */
@FunctionalInterface
@SarlSpecification("0.13")
@SarlElementType(11)
@SuppressWarnings("all")
public interface Filter<T extends Object> {
  /**
   * Computes the filtered value from the input v
   * @param v the input
   * @return the filtered output
   */
  T filter(final T v);
}
