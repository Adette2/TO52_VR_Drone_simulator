package io.sarl.airsim.simulation.scheduling;

import io.sarl.lang.core.annotation.SarlElementType;
import io.sarl.lang.core.annotation.SarlSpecification;
import io.sarl.lang.core.annotation.SyntheticMember;
import org.eclipse.xtext.xbase.lib.ObjectExtensions;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure0;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;
import org.eclipse.xtext.xbase.lib.Pure;

/**
 * Real-time scheduling strategy. When a loop is run the perceptions are retrieved.
 * The simulation is never paused.
 * @author Alexandre Lombard
 */
@SarlSpecification("0.13")
@SarlElementType(10)
@SuppressWarnings("all")
public class RealTimeSimulationStrategy implements SimulationStrategy {
  @SarlSpecification("0.13")
  @SarlElementType(10)
  public static class RealTimeSimulationStrategyBuilder {
    public Procedure0 retrievePerceptionsBy;

    @Pure
    public RealTimeSimulationStrategy build() {
      return new RealTimeSimulationStrategy(this.retrievePerceptionsBy);
    }

    @Override
    @Pure
    @SyntheticMember
    public boolean equals(final Object obj) {
      return super.equals(obj);
    }

    @Override
    @Pure
    @SyntheticMember
    public int hashCode() {
      int result = super.hashCode();
      return result;
    }

    @SyntheticMember
    public RealTimeSimulationStrategyBuilder() {
      super();
    }
  }

  private final Procedure0 retrievePerceptions;

  public RealTimeSimulationStrategy(final Procedure0 retrievePerceptions) {
    this.retrievePerceptions = retrievePerceptions;
  }

  public void loop() {
    this.retrievePerceptions.apply();
  }

  /**
   * Builds a RealTimeSimulationStrategy
   */
  @Pure
  public static RealTimeSimulationStrategy realTimeSimulationStrategy(final Procedure1<RealTimeSimulationStrategy.RealTimeSimulationStrategyBuilder> init) {
    RealTimeSimulationStrategy.RealTimeSimulationStrategyBuilder _realTimeSimulationStrategyBuilder = new RealTimeSimulationStrategy.RealTimeSimulationStrategyBuilder();
    final RealTimeSimulationStrategy.RealTimeSimulationStrategyBuilder strategyBuilder = ObjectExtensions.<RealTimeSimulationStrategy.RealTimeSimulationStrategyBuilder>operator_doubleArrow(_realTimeSimulationStrategyBuilder, init);
    return strategyBuilder.build();
  }

  @Override
  @Pure
  @SyntheticMember
  public boolean equals(final Object obj) {
    return super.equals(obj);
  }

  @Override
  @Pure
  @SyntheticMember
  public int hashCode() {
    int result = super.hashCode();
    return result;
  }
}
