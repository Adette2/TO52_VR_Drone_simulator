package io.sarl.airsim.filters.mean;

import io.sarl.airsim.filters.Filter;
import io.sarl.lang.core.annotation.SarlElementType;
import io.sarl.lang.core.annotation.SarlSpecification;
import io.sarl.lang.core.annotation.SyntheticMember;
import java.util.List;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.IntegerRange;
import org.eclipse.xtext.xbase.lib.Pure;

/**
 * Abstract mean filter
 * @author Alexandre Lombard
 */
@SarlSpecification("0.13")
@SarlElementType(10)
@SuppressWarnings("all")
public abstract class AbstractMeanFilter<T extends Object> implements Filter<T> {
  /**
   * The kernel of the filter
   */
  protected final List<T> values;

  /**
   * The current index for the position to add a new value
   */
  private int currentIndex = 0;

  public AbstractMeanFilter(final Integer size, final T defaultValue) {
    this.values = CollectionLiterals.<T>newArrayList();
    IntegerRange _upTo = new IntegerRange(0, ((size) == null ? 0 : (size).intValue()));
    for (final Integer i : _upTo) {
      this.values.add(defaultValue);
    }
  }

  protected int addValue(final T value) {
    int _xblockexpression = (int) 0;
    {
      this.values.set(this.currentIndex, value);
      int _length = ((Object[])Conversions.unwrapArray(this.values, Object.class)).length;
      _xblockexpression = this.currentIndex = ((this.currentIndex + 1) % _length);
    }
    return _xblockexpression;
  }

  @Override
  @Pure
  @SyntheticMember
  public boolean equals(final Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    AbstractMeanFilter<T> other = (AbstractMeanFilter<T>) obj;
    if (other.currentIndex != this.currentIndex)
      return false;
    return super.equals(obj);
  }

  @Override
  @Pure
  @SyntheticMember
  public int hashCode() {
    int result = super.hashCode();
    final int prime = 31;
    result = prime * result + Integer.hashCode(this.currentIndex);
    return result;
  }
}
