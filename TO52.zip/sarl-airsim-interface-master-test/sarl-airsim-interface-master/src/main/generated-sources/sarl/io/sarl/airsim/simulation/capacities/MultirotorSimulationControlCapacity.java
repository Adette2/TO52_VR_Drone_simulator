package io.sarl.airsim.simulation.capacities;

import io.sarl.lang.core.AgentTrait;
import io.sarl.lang.core.Capacity;
import io.sarl.lang.core.annotation.SarlElementType;
import io.sarl.lang.core.annotation.SarlSpecification;

/**
 * Capacity to control a multirotor body in the simulation.
 * This capacity should be given to the simulation controller agent.
 * @author Alexandre Lombard
 */
@SarlSpecification("0.13")
@SarlElementType(20)
@SuppressWarnings("all")
public interface MultirotorSimulationControlCapacity extends Capacity {
  /**
   * A method to call in order to enable the control of the vehicle
   * @param vehicleName the name of the vehicle to control
   */
  void enableControl(final String vehicleName);

  /**
   * Take-off order for the given vehicle
   * @param vehicleName the identifier of the vehicle
   */
  void takeOff(final String vehicleName);

  /**
   * Land order for the given vehicle
   * @param vehicleName the identifier of the vehicle
   */
  void land(final String vehicleName);

  /**
   * Go-home order for the given vehicle
   * @param vehicleName the identifier of the vehicle
   */
  void goHome(final String vehicleName);

  /**
   * Move-by-velocity order for the given vehicle
   * @param vehicleName the identifier of the vehicle
   * @param vx the velocity along the x axis
   * @param vy the velocity along the y axis
   * @param vz the velocity along the z axis
   * @param duration the duration of the movement in seconds
   */
  void moveByVelocity(final String vehicleName, final Float vx, final Float vy, final Float vz, final Float duration);

  /**
   * Move-to-position order for the given vehicle
   * @param vehicleName the identifier of the vehicle
   * @param x the x position
   * @param y the y position
   * @param z the z position
   */
  void moveToPosition(final String vehicleName, final Float x, final Float y, final Float z, final Float velocity);

  /**
   * Rotate-by-yaw-rate order for the given vehicle
   * @param vehicleName the identifier of the vehicle
   * @param yawRate the yaw rate
   * @param duration the duration of the order in seconds
   */
  void rotateByYawRate(final String vehicleName, final Float yawRate, final Float duration);

  /**
   * Rotate-to-yaw order for the given vehicle
   * @param vehicleName the identifier of the vehicle
   * @param yaw the target yaw angle
   */
  void rotateToYaw(final String vehicleName, final Float yaw);

  /**
   * @ExcludeFromApidoc
   */
  class ContextAwareCapacityWrapper<C extends MultirotorSimulationControlCapacity> extends Capacity.ContextAwareCapacityWrapper<C> implements MultirotorSimulationControlCapacity {
    public ContextAwareCapacityWrapper(final C capacity, final AgentTrait caller) {
      super(capacity, caller);
    }

    public void enableControl(final String vehicleName) {
      try {
        ensureCallerInLocalThread();
        this.capacity.enableControl(vehicleName);
      } finally {
        resetCallerInLocalThread();
      }
    }

    public void takeOff(final String vehicleName) {
      try {
        ensureCallerInLocalThread();
        this.capacity.takeOff(vehicleName);
      } finally {
        resetCallerInLocalThread();
      }
    }

    public void land(final String vehicleName) {
      try {
        ensureCallerInLocalThread();
        this.capacity.land(vehicleName);
      } finally {
        resetCallerInLocalThread();
      }
    }

    public void goHome(final String vehicleName) {
      try {
        ensureCallerInLocalThread();
        this.capacity.goHome(vehicleName);
      } finally {
        resetCallerInLocalThread();
      }
    }

    public void moveByVelocity(final String vehicleName, final Float vx, final Float vy, final Float vz, final Float duration) {
      try {
        ensureCallerInLocalThread();
        this.capacity.moveByVelocity(vehicleName, vx, vy, vz, duration);
      } finally {
        resetCallerInLocalThread();
      }
    }

    public void moveToPosition(final String vehicleName, final Float x, final Float y, final Float z, final Float velocity) {
      try {
        ensureCallerInLocalThread();
        this.capacity.moveToPosition(vehicleName, x, y, z, velocity);
      } finally {
        resetCallerInLocalThread();
      }
    }

    public void rotateByYawRate(final String vehicleName, final Float yawRate, final Float duration) {
      try {
        ensureCallerInLocalThread();
        this.capacity.rotateByYawRate(vehicleName, yawRate, duration);
      } finally {
        resetCallerInLocalThread();
      }
    }

    public void rotateToYaw(final String vehicleName, final Float yaw) {
      try {
        ensureCallerInLocalThread();
        this.capacity.rotateToYaw(vehicleName, yaw);
      } finally {
        resetCallerInLocalThread();
      }
    }
  }
}
