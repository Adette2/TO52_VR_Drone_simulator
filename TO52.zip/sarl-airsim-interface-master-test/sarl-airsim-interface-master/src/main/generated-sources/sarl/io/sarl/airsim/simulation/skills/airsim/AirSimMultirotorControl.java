package io.sarl.airsim.simulation.skills.airsim;

import fr.utbm.airsim.api.DrivetrainType;
import fr.utbm.airsim.api.MultirotorClientInterface;
import fr.utbm.airsim.api.YawMode;
import io.sarl.airsim.simulation.capacities.MultirotorSimulationControlCapacity;
import io.sarl.lang.core.Skill;
import io.sarl.lang.core.annotation.SarlElementType;
import io.sarl.lang.core.annotation.SarlSpecification;
import io.sarl.lang.core.annotation.SyntheticMember;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.Pure;
import org.msgpack.rpc.Client;
import org.msgpack.rpc.loop.EventLoop;

/**
 * AirSim implementation of the multirotor simulation control capacity
 * @author Alexandre Lombard
 */
@SarlSpecification("0.13")
@SarlElementType(22)
@SuppressWarnings("all")
public class AirSimMultirotorControl extends Skill implements MultirotorSimulationControlCapacity {
  private final EventLoop loop = EventLoop.defaultEventLoop();

  private final Client rpcClient;

  private final MultirotorClientInterface rpcLibClient;

  private final float defaultTimeout = 5.0f;

  public AirSimMultirotorControl() {
    this("127.0.0.1", Integer.valueOf(41451));
  }

  public AirSimMultirotorControl(final String ipAddress, final Integer port) {
    try {
      Client _client = new Client(ipAddress, ((port) == null ? 0 : (port).intValue()), this.loop);
      this.rpcClient = _client;
      this.rpcLibClient = this.rpcClient.<MultirotorClientInterface>proxy(MultirotorClientInterface.class);
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }

  public void install() {
  }

  public void uninstall() {
  }

  @Override
  public void enableControl(final String vehicleName) {
    synchronized (this.rpcLibClient) {
      this.rpcLibClient.enableApiControl(true, vehicleName);
    }
  }

  @Override
  public void takeOff(final String vehicleName) {
    synchronized (this.rpcLibClient) {
      this.rpcLibClient.takeoffAsync(this.defaultTimeout, vehicleName);
    }
  }

  @Override
  public void land(final String vehicleName) {
    synchronized (this.rpcLibClient) {
      this.rpcLibClient.landAsync(this.defaultTimeout, vehicleName);
    }
  }

  @Override
  public void rotateByYawRate(final String vehicleName, final Float yawRate, final Float duration) {
    synchronized (this.rpcLibClient) {
      this.rpcLibClient.rotateByYawRateAsync(((yawRate) == null ? 0 : (yawRate).floatValue()), ((duration) == null ? 0 : (duration).floatValue()), vehicleName);
    }
  }

  @Override
  public void rotateToYaw(final String vehicleName, final Float yaw) {
    synchronized (this.rpcLibClient) {
      this.rpcLibClient.rotateToYawAsync(((yaw) == null ? 0 : (yaw).floatValue()), this.defaultTimeout, 5.0f, vehicleName);
    }
  }

  @Override
  public void goHome(final String vehicleName) {
    synchronized (this.rpcLibClient) {
      this.rpcLibClient.goHomeAsync(this.defaultTimeout, vehicleName);
    }
  }

  @Override
  public void moveToPosition(final String vehicleName, final Float x, final Float y, final Float z, final Float velocity) {
    synchronized (this.rpcLibClient) {
      YawMode _yawMode = new YawMode();
      this.rpcLibClient.moveToPositionAsync(((x) == null ? 0 : (x).floatValue()), ((y) == null ? 0 : (y).floatValue()), ((z) == null ? 0 : (z).floatValue()), ((velocity) == null ? 0 : (velocity).floatValue()), this.defaultTimeout, DrivetrainType.MAX_DEGREE_OF_FREEDOM, _yawMode, (-1.0f), (-1.0f), vehicleName);
    }
  }

  @Override
  public void moveByVelocity(final String vehicleName, final Float vx, final Float vy, final Float vz, final Float duration) {
    synchronized (this.rpcLibClient) {
      YawMode _yawMode = new YawMode();
      this.rpcLibClient.moveByVelocityAsync(((vx) == null ? 0 : (vx).floatValue()), ((vy) == null ? 0 : (vy).floatValue()), ((vz) == null ? 0 : (vz).floatValue()), ((duration) == null ? 0 : (duration).floatValue()), DrivetrainType.MAX_DEGREE_OF_FREEDOM, _yawMode, vehicleName);
    }
  }

  @Override
  @Pure
  @SyntheticMember
  public boolean equals(final Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    AirSimMultirotorControl other = (AirSimMultirotorControl) obj;
    if (Float.floatToIntBits(other.defaultTimeout) != Float.floatToIntBits(this.defaultTimeout))
      return false;
    return super.equals(obj);
  }

  @Override
  @Pure
  @SyntheticMember
  public int hashCode() {
    int result = super.hashCode();
    final int prime = 31;
    result = prime * result + Float.hashCode(this.defaultTimeout);
    return result;
  }
}
