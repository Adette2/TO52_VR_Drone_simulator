package io.sarl.airsim.simulation.influence;

import io.sarl.lang.core.Address;
import io.sarl.lang.core.annotation.DefaultValue;
import io.sarl.lang.core.annotation.DefaultValueSource;
import io.sarl.lang.core.annotation.DefaultValueUse;
import io.sarl.lang.core.annotation.SarlElementType;
import io.sarl.lang.core.annotation.SarlSourceCode;
import io.sarl.lang.core.annotation.SarlSpecification;
import io.sarl.lang.core.annotation.SyntheticMember;
import java.util.Collection;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.function.Consumer;
import org.eclipse.xtext.xbase.lib.Functions.Function2;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure0;
import org.eclipse.xtext.xbase.lib.Pure;

/**
 * Influences and perceptions are collected, they are propagated only when a condition
 * has been met.
 * An agent is able to emit several influences without them being applied immediately. So it can has
 * several pending influences. If so, they will be all emitted at once later.
 * The same goes for perceptions.
 * @author Alexandre Lombard
 */
@SarlSpecification("0.13")
@SarlElementType(10)
@SuppressWarnings("all")
public class BatchedInfluenceReactionStrategy implements InfluenceReactionStrategy {
  private final ConcurrentHashMap<Address, BlockingQueue<Procedure0>> perceptions = new ConcurrentHashMap<Address, BlockingQueue<Procedure0>>();

  private final ConcurrentHashMap<Address, BlockingQueue<Procedure0>> influences = new ConcurrentHashMap<Address, BlockingQueue<Procedure0>>();

  private final Function2<? super Long, ? super Collection<Address>, ? extends Boolean> perceptionPropagationCondition;

  private final Function2<? super Long, ? super Collection<Address>, ? extends Boolean> influencePropagationCondition;

  private Procedure0 perceptionsPropagationListener;

  private Procedure0 influencesPropagationListener;

  private final int influenceBufferSize;

  private final boolean influenceDropOld;

  private long lastPerceptionPropagationTimeMs = 0L;

  private long lastInfluencePropagationTimeMs = 0L;

  @DefaultValueSource
  public BatchedInfluenceReactionStrategy(final Function2<? super Long, ? super Collection<Address>, ? extends Boolean> perceptionPropagationCondition, final Function2<? super Long, ? super Collection<Address>, ? extends Boolean> influencePropagationCondition, @DefaultValue("io.sarl.airsim.simulation.influence.BatchedInfluenceReactionStrategy#NEW_0") final int influenceBufferSize, @DefaultValue("io.sarl.airsim.simulation.influence.BatchedInfluenceReactionStrategy#NEW_1") final boolean influenceDropOld) {
    this.perceptionPropagationCondition = perceptionPropagationCondition;
    this.influencePropagationCondition = influencePropagationCondition;
    this.influenceBufferSize = influenceBufferSize;
    this.influenceDropOld = influenceDropOld;
  }

  public void perceptionReceived(final Address destination, final Procedure0 propagate) {
    boolean _containsKey = this.perceptions.containsKey(destination);
    if ((!_containsKey)) {
      LinkedBlockingQueue<Procedure0> _linkedBlockingQueue = new LinkedBlockingQueue<Procedure0>();
      this.perceptions.put(destination, _linkedBlockingQueue);
    }
    this.perceptions.get(destination).add(propagate);
    long _currentTimeMillis = System.currentTimeMillis();
    Boolean _apply = this.perceptionPropagationCondition.apply(Long.valueOf((_currentTimeMillis - this.lastPerceptionPropagationTimeMs)), this.perceptions.keySet());
    if (((_apply) == null ? false : (_apply).booleanValue())) {
      final Consumer<BlockingQueue<Procedure0>> _function = (BlockingQueue<Procedure0> it) -> {
        final Consumer<Procedure0> _function_1 = (Procedure0 it_1) -> {
          it_1.apply();
        };
        it.forEach(_function_1);
      };
      this.perceptions.values().forEach(_function);
      this.perceptions.clear();
      this.lastPerceptionPropagationTimeMs = System.currentTimeMillis();
      this.firePerceptionsPropagated();
    }
  }

  public void influenceReceived(final Address source, final Procedure0 propagate) {
    boolean _containsKey = this.influences.containsKey(source);
    if ((!_containsKey)) {
      LinkedBlockingQueue<Procedure0> _linkedBlockingQueue = new LinkedBlockingQueue<Procedure0>();
      this.influences.put(source, _linkedBlockingQueue);
    }
    if (((this.influenceBufferSize > 0) && (this.influences.get(source).size() >= this.influenceBufferSize))) {
      if (this.influenceDropOld) {
        this.influences.get(source).poll();
      } else {
      }
    }
    this.influences.get(source).add(propagate);
    long _currentTimeMillis = System.currentTimeMillis();
    Boolean _apply = this.influencePropagationCondition.apply(Long.valueOf((_currentTimeMillis - this.lastInfluencePropagationTimeMs)), 
      this.influences.keySet());
    if (((_apply) == null ? false : (_apply).booleanValue())) {
      final Consumer<BlockingQueue<Procedure0>> _function = (BlockingQueue<Procedure0> it) -> {
        final Consumer<Procedure0> _function_1 = (Procedure0 it_1) -> {
          it_1.apply();
        };
        it.forEach(_function_1);
      };
      this.influences.values().forEach(_function);
      this.influences.clear();
      this.lastInfluencePropagationTimeMs = System.currentTimeMillis();
      this.fireInfluencesPropagated();
    } else {
    }
  }

  public void clearPerceptions() {
    this.perceptions.clear();
  }

  /**
   * Clear all pending influences, it can be useful if we want, for instance,
   * to remove all influences emitted just before the perceptions are being retrieved
   */
  public void clearInfluences() {
    this.influences.clear();
  }

  public void onPerceptionsPropagated(final Procedure0 action) {
    this.perceptionsPropagationListener = action;
  }

  public void onInfluencesPropagated(final Procedure0 action) {
    this.influencesPropagationListener = action;
  }

  protected void firePerceptionsPropagated() {
    if ((this.perceptionsPropagationListener != null)) {
      this.perceptionsPropagationListener.apply();
    }
  }

  protected void fireInfluencesPropagated() {
    if ((this.influencesPropagationListener != null)) {
      this.influencesPropagationListener.apply();
    }
  }

  /**
   * Default value for the parameter influenceBufferSize
   */
  @Pure
  @SyntheticMember
  @SarlSourceCode("0")
  private static int $DEFAULT_VALUE$NEW_0() {
    return 0;
  }

  /**
   * Default value for the parameter influenceDropOld
   */
  @Pure
  @SyntheticMember
  @SarlSourceCode("true")
  private static boolean $DEFAULT_VALUE$NEW_1() {
    return true;
  }

  @DefaultValueUse("(java.lang.Long, java.util.Collection<io.sarl.lang.core.Address>)=>java.lang.Boolean,(java.lang.Long, java.util.Collection<io.sarl.lang.core.Address>)=>java.lang.Boolean,int,boolean")
  @SyntheticMember
  public BatchedInfluenceReactionStrategy(final Function2<? super Long, ? super Collection<Address>, ? extends Boolean> perceptionPropagationCondition, final Function2<? super Long, ? super Collection<Address>, ? extends Boolean> influencePropagationCondition) {
    this(perceptionPropagationCondition, influencePropagationCondition, $DEFAULT_VALUE$NEW_0(), $DEFAULT_VALUE$NEW_1());
  }

  @DefaultValueUse("(java.lang.Long, java.util.Collection<io.sarl.lang.core.Address>)=>java.lang.Boolean,(java.lang.Long, java.util.Collection<io.sarl.lang.core.Address>)=>java.lang.Boolean,int,boolean")
  @SyntheticMember
  public BatchedInfluenceReactionStrategy(final Function2<? super Long, ? super Collection<Address>, ? extends Boolean> perceptionPropagationCondition, final Function2<? super Long, ? super Collection<Address>, ? extends Boolean> influencePropagationCondition, final boolean influenceDropOld) {
    this(perceptionPropagationCondition, influencePropagationCondition, $DEFAULT_VALUE$NEW_0(), influenceDropOld);
  }

  @DefaultValueUse("(java.lang.Long, java.util.Collection<io.sarl.lang.core.Address>)=>java.lang.Boolean,(java.lang.Long, java.util.Collection<io.sarl.lang.core.Address>)=>java.lang.Boolean,int,boolean")
  @SyntheticMember
  public BatchedInfluenceReactionStrategy(final Function2<? super Long, ? super Collection<Address>, ? extends Boolean> perceptionPropagationCondition, final Function2<? super Long, ? super Collection<Address>, ? extends Boolean> influencePropagationCondition, final int influenceBufferSize) {
    this(perceptionPropagationCondition, influencePropagationCondition, influenceBufferSize, $DEFAULT_VALUE$NEW_1());
  }

  @Override
  @Pure
  @SyntheticMember
  public boolean equals(final Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    BatchedInfluenceReactionStrategy other = (BatchedInfluenceReactionStrategy) obj;
    if (other.influenceBufferSize != this.influenceBufferSize)
      return false;
    if (other.influenceDropOld != this.influenceDropOld)
      return false;
    if (other.lastPerceptionPropagationTimeMs != this.lastPerceptionPropagationTimeMs)
      return false;
    if (other.lastInfluencePropagationTimeMs != this.lastInfluencePropagationTimeMs)
      return false;
    return super.equals(obj);
  }

  @Override
  @Pure
  @SyntheticMember
  public int hashCode() {
    int result = super.hashCode();
    final int prime = 31;
    result = prime * result + Integer.hashCode(this.influenceBufferSize);
    result = prime * result + Boolean.hashCode(this.influenceDropOld);
    result = prime * result + Long.hashCode(this.lastPerceptionPropagationTimeMs);
    result = prime * result + Long.hashCode(this.lastInfluencePropagationTimeMs);
    return result;
  }
}
