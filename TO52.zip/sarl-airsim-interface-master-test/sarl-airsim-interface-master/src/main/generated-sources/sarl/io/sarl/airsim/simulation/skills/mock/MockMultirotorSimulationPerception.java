package io.sarl.airsim.simulation.skills.mock;

import fr.utbm.airsim.api.MultirotorState;
import io.sarl.airsim.simulation.capacities.MultirotorSimulationPerceptionCapacity;
import io.sarl.lang.core.Agent;
import io.sarl.lang.core.Skill;
import io.sarl.lang.core.annotation.SarlElementType;
import io.sarl.lang.core.annotation.SarlSpecification;
import io.sarl.lang.core.annotation.SyntheticMember;
import org.eclipse.xtext.xbase.lib.Pure;

/**
 * Mock for the multirotor simulation perception implementing the corresponding capacity.
 * The behavior is to return empty and constant perceptions.
 * @author Alexandre Lombard
 */
@SarlSpecification("0.13")
@SarlElementType(22)
@SuppressWarnings("all")
public class MockMultirotorSimulationPerception extends Skill implements MultirotorSimulationPerceptionCapacity {
  @Pure
  public MultirotorState getMultirotorState(final String vehicleName) {
    return new MultirotorState();
  }

  @SyntheticMember
  public MockMultirotorSimulationPerception() {
    super();
  }

  @SyntheticMember
  public MockMultirotorSimulationPerception(final Agent arg0) {
    super(arg0);
  }
}
