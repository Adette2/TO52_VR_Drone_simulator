rootProject.name = "airsim-jvm-api"
